# Phase 3 Setup Notes

## Files

```
/admin/endorsements/admin.css                  (shared styles)
/admin/endorsements/index.html                  (applications list)
/admin/endorsements/login/index.html            (magic-link sign in)
/admin/endorsements/detail/index.html           (application detail + actions)

/endorsement/screening/index.html               (form, Cloudflare-stripped)
/endorsement/screening/thank-you/index.html     (unchanged)
```

Drop all of these into the matching paths in your Netlify repo.

## Form Update (Cloudflare Stripped)

Turnstile is gone. In its place:
- **Honeypot field**. A hidden input bots will autofill. Submissions where it's filled are silently dropped.
- **Time check**. Submissions in under 4 seconds are silently dropped. A real candidate with 30+ fields cannot submit that fast.
- The CONFIG block now only has `SUPABASE_ANON_KEY` to fill in. No Turnstile site key needed.

Both checks behave as quiet failures so bots don't get useful feedback. We can layer on Cloudflare Turnstile any time later by reverting to the Phase 2 file and adding the site key.

## Admin Dashboard

### Configuration

Each of the three admin pages has the same `CONFIG` block at the top of its inline script. Replace `__PASTE_SUPABASE_ANON_KEY__` with the same anon key used in the form. Same key everywhere is correct.

### Magic-link sign-in flow

1. User goes to `/admin/endorsements/login`
2. Enters email, clicks "Send Magic Link"
3. Supabase sends them an email with a one-time link
4. Clicking the link redirects to `https://ohiopride.org/admin/endorsements` with auth tokens in the URL fragment
5. The list page detects the session, verifies the email is in `admin_emails`, and renders the app
6. If the email is NOT in `admin_emails`, they're signed out and shown an "Access denied" page

The redirect URL is hardcoded as `https://ohiopride.org/admin/endorsements`. Make sure this is in the **Authentication > URL Configuration > Redirect URLs** allowlist in Supabase (it should be from Phase 1).

### List page features

- Sortable table on Candidate, Office, District, Status, Submitted (default sort: Submitted desc)
- Live search by name or email
- Status filter dropdown
- Office filter (free text contains)
- Stat counts at top: Total / New / In Review / Endorsed
- Click any row to open the detail page
- Empty state distinguishes "no applications yet" from "no matches"
- Mobile: table collapses to cards

### Detail page features

- Crumb link back to the list
- Pride-gradient banner across the candidate card top
- Candidate header: name, pronouns, status badge, office, district, year, party pills
- Six sections: Candidate Information, Core Positions (with yes/no badges color-coded green/red), Legislative Commitment, Vision and Ohio Context, Background and Attestation, Audit Trail
- Sticky sidebar (desktop) with three cards:
  - **Status** dropdown with helper text noting that "Endorsed" auto-publishes to the public page
  - **Reviewer Notes** textarea (internal only, RLS hides this from anon)
  - **Actions**: Save Changes button, Generate PDF button, Open Last PDF link if one exists
- Save updates `status` and `reviewer_notes` and re-renders the badge in the header
- Generate PDF posts to `/.netlify/functions/generate-endorsement-pdf` with the current session's JWT. Until Phase 4 deploys that function, the button shows a friendly "Coming in Phase 4" toast on 404.
- Open Last PDF creates a 24-hour signed URL from Storage and opens the existing PDF in a new tab

### URL pattern

Detail pages use a query string: `/admin/endorsements/detail?id={uuid}`. No Netlify redirects needed. If you ever want pretty URLs like `/admin/endorsements/{uuid}`, that's a one-line `_redirects` rule we can add later.

## Test Plan

After deploying with the anon key filled in:

1. Visit `/admin/endorsements`. Should redirect to `/admin/endorsements/login` since you have no session.
2. On the login page, enter `zach@ohiopride.org`, click Send Magic Link. Should see "Check your email" success state.
3. Open the email, click the link. Should land back on the list page, verify your email shown in the header.
4. Try signing in with an unauthorized email (e.g., your personal Gmail). Should land on the "Access denied" page after auth.
5. Submit a test application via `/endorsement/screening`. Refresh the admin list. The new row should appear.
6. Click into the test application. All sections should populate with the right data.
7. Change status to "Under Review", add a reviewer note, click Save. Header badge should update. Refresh and confirm persistence.
8. Click Generate PDF. Should toast "PDF generator not deployed yet. Coming in Phase 4." (Expected before Phase 4.)
9. Sign out from the header. Should redirect to login.

## Known Items for Later Phases

- **Phase 4** wires up `/.netlify/functions/generate-endorsement-pdf` so the Generate PDF button actually produces the branded PDF.
- **Phase 5** adds the on-INSERT trigger that emails confirmations to candidates and alerts to you. Right now the thank-you page still promises an email; nothing's actually wired yet.
- **Phase 6** is the public endorsements page that auto-pulls from the `public_endorsements` view when a status flips to "endorsed".

## Brand Compliance

- Navy #0F2233 dominant background, used in headers, buttons, footer
- Light Blue #73D7EE for accents, eyebrows, focus rings, the cyan PDF button
- Pride gradient on top stripe (14px), bottom stripe (10px), and the candidate card banner (6px)
- Montserrat for headlines, labels, buttons, eyebrows
- Roboto Slab for body, table data, response text
- "out" used in the candidate identity pill (not "openly")
- No em dashes, no en dashes
- Footer disclaimer on every admin page
