# Phase 2 Setup Notes

## Files

Drop these into your Netlify repo at the matching paths:

```
/endorsement/screening/index.html
/endorsement/screening/thank-you/index.html
```

## Configuration

The form has a single `CONFIG` block near the top of the inline script
in `/endorsement/screening/index.html`. Replace the two placeholders
before deploying:

```javascript
const CONFIG = {
  SUPABASE_URL:        'https://dkdxefzhttkmjhdbkvqn.supabase.co',
  SUPABASE_ANON_KEY:   '__PASTE_SUPABASE_ANON_KEY__',
  TURNSTILE_SITE_KEY:  '__PASTE_TURNSTILE_SITE_KEY__',
  THANK_YOU_PATH:      '/endorsement/screening/thank-you',
  STORAGE_KEY:         'op_endorsement_draft_v1',
  AUTOSAVE_DEBOUNCE_MS: 600
};
```

### Where each value comes from

1. **SUPABASE_URL** — already filled in (your Ohio Pride project).
2. **SUPABASE_ANON_KEY** — Supabase Dashboard → Project Settings → API → "Project API keys" → copy the `anon public` key.
3. **TURNSTILE_SITE_KEY** — Cloudflare Dashboard → Turnstile → Add site → enter `ohiopride.org` → copy the **Site Key**. (The Secret Key stays server-side; we'll use it in Phase 5 for token verification.)

Both keys are designed to be public and are safe to ship in client code. The Supabase service role key and Turnstile secret key should never appear here.

## Deployment

This is pure static HTML. No build step. Push the files to your main
branch and Netlify will deploy them automatically.

## What's Wired Up

- 5-step form with progress bar, autosave, client-side validation
- Direct submit to Supabase via anon key (insert only, RLS enforced)
- Turnstile widget renders on Step 5 (final step before submit)
- On success, draft is cleared from localStorage and user is sent to /endorsement/screening/thank-you
- On error, Turnstile resets and user can retry without re-entering data

## What's Not Wired Up Yet (Phase 5)

- Server-side Turnstile token verification. Right now the widget blocks the most basic bots client-side, but a determined attacker could submit without a valid token. Phase 5 will add a Supabase Edge Function or Netlify Function that verifies the token against Cloudflare's API before accepting the submission.
- Confirmation email to candidate. Currently the thank-you page promises an email; Phase 5 wires up the trigger.
- Director alert email. Same.

If you want spam protection tightened before Phase 5, the simplest interim option is to set Turnstile's challenge mode to "Managed" in the Cloudflare dashboard, which is slightly more aggressive than "Non-Interactive."

## Test Plan

After deploying with real keys:

1. Visit `/endorsement/screening` on desktop and mobile.
2. Fill Step 1 with junk data, click Next without filling required fields, confirm the inline errors render.
3. Walk through all 5 steps with valid data. Use the test candidate email `test@example.com`.
4. Refresh the page mid-form, confirm autosave restored your data.
5. On Step 5, submit. Should redirect to thank-you page.
6. Open Supabase SQL Editor and run:
   ```sql
   select id, candidate_name, email, status, created_at
   from public.endorsement_applications
   where email = 'test@example.com'
   order by created_at desc;
   ```
   You should see the row.
7. Clean up with:
   ```sql
   delete from public.endorsement_applications where email = 'test@example.com';
   ```

## Brand Compliance Check

- Navy #0F2233 dominant background
- Light Blue #73D7EE accent on eyebrow text, focus rings, primary CTA
- Pride gradient on top stripe (14px), bottom stripe (10px), progress bar fill, and the thank-you card banner
- Montserrat for all headlines, labels, buttons, eyebrows
- Roboto Slab for body copy and form input text
- "out" used in the "Are you out as LGBTQ+?" question (not "openly")
- No em dashes or en dashes anywhere in the copy
- Footer disclaimer: "Paid for by Ohio Pride PAC. Zachary R. Joseph, Director."
