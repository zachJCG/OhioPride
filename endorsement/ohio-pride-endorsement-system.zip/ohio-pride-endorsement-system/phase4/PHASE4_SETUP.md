# Phase 4 Setup Notes

## Files

```
/netlify.toml                                          (or merge with existing)
/netlify/functions/generate-endorsement-pdf.py         (the function)
/netlify/functions/requirements.txt                    (Python deps)
```

Drop into matching paths in your Netlify repo.

## Environment Variables

Set these in **Netlify Dashboard > Site Configuration > Environment Variables**. They are server-side only; never embedded in client code.

| Variable | Value | Notes |
|---|---|---|
| `SUPABASE_URL` | `https://dkdxefzhttkmjhdbkvqn.supabase.co` | Your Ohio Pride project |
| `SUPABASE_ANON_KEY` | (anon public key) | Same as in the form and admin pages |
| `SUPABASE_SERVICE_ROLE_KEY` | (service role key) | **Sensitive.** Server-only. Bypasses RLS. |
| `ADMIN_EMAIL` | `zach@ohiopride.org` | Authorized admin. Must match a row in `admin_emails`. |

The service role key is in **Supabase Dashboard > Project Settings > API > Project API keys > service_role**. Treat it like a database password. Never paste it into client code or commit it to the repo.

After setting env vars, redeploy the site so the function picks them up.

## What the Function Does

1. Verifies the JWT in `Authorization: Bearer ...` by calling Supabase's `/auth/v1/user` endpoint
2. Confirms the verified email matches `ADMIN_EMAIL`
3. Fetches the application row using the service role key (bypasses RLS)
4. Generates a branded multi-page PDF with ReportLab
5. Uploads to Supabase Storage at `endorsement-pdfs/{application_id}.pdf` (upsert, so regenerating overwrites)
6. Updates `generated_pdf_path` on the application row to `endorsement-pdfs/{application_id}.pdf`
7. Creates a 7-day signed URL and returns it

## PDF Layout

Each page has:
- 10pt pride gradient stripe at top
- 44pt navy header band with "OhioPride PAC" wordmark and "ENDORSEMENT APPLICATION" eyebrow
- Body content (frame margins handled automatically)
- 32pt navy footer band with disclaimer and page number
- 7pt pride gradient stripe at bottom

Page 1 starts with candidate name (with pronouns inline), office and meta line, status badge, then sections:
- Section 1: Candidate Information (two-column info grid with "Not provided" fallbacks)
- Section 2: Core Positions (5 question blocks with Yes/No/No-answer badges, color-coded left bars)
- Section 3: Legislative and Advocacy Commitment (3 open responses)
- Section 4: Vision and Ohio Context (2 open responses)
- Section 5: Background and Attestation (bio, conflicts, attestation row)
- Audit Trail (application ID, timestamps, status)

Sample output runs about 3 pages and 36KB for a complete application.

## Test Plan

After deploying with env vars set:

1. **Submit a test application** via `/endorsement/screening` so you have a row to PDF.
2. **Sign in** to `/admin/endorsements/login`, find the test application, click into its detail page.
3. **Click Generate PDF**. Watch the toast.
   - If you see "PDF generated.", the new browser tab should open the PDF.
   - If you see an error, check the function logs in Netlify Dashboard > Functions > generate-endorsement-pdf > Logs.
4. **Refresh the detail page**. The "Open Last PDF" link should now appear under the Generate PDF button. Click it. Should open the same PDF.
5. **Check the row in Supabase**:
   ```sql
   select id, candidate_name, generated_pdf_path
   from public.endorsement_applications
   where email = 'test@example.com';
   ```
   `generated_pdf_path` should be `endorsement-pdfs/{id}.pdf`.
6. **Check the Storage bucket** in the Supabase dashboard under Storage > endorsement-pdfs. The file should be there.

## Common Issues

**"PDF generator not deployed yet" toast** in admin → the function returned 404. Confirm `netlify/functions/generate-endorsement-pdf.py` made it into the build. Check Netlify deploy logs for the function being detected.

**500 error from function** → check Netlify function logs. Most likely: missing env var (especially `SUPABASE_SERVICE_ROLE_KEY`) or the Storage bucket `endorsement-pdfs` doesn't exist yet (Phase 1 manual step).

**401 "Invalid or expired session token"** → the admin user's session expired. They need to sign in again on the admin login page.

**403 "Not authorized"** → the JWT email doesn't match `ADMIN_EMAIL`. Check that `ADMIN_EMAIL` env var is set correctly and matches the case of the email in `admin_emails`.

**PDF generation slow on first call** → cold start. ReportLab takes ~1.5s to import on a fresh container. Subsequent calls in the same warm window are ~500ms.

## Cost / Limits

Netlify Functions free tier: 125k requests and 100 hours of execution per month. Each PDF generation uses ~1 invocation and runs in 1 to 3 seconds. You'd need to generate >40k PDFs/month before hitting the cap.

Supabase Storage free tier: 1 GB storage, 2 GB bandwidth/month. At ~36KB per PDF, that's room for ~28k applications stored before hitting the storage cap. Bandwidth is the bigger concern if PDFs are downloaded frequently.

## Brand Compliance

- Navy #0F2233 dominant, header and footer bands
- Light Blue #73D7EE for eyebrows, "PAC" suffix, accent rules, page number
- Pride gradient on top stripe (10pt) and bottom stripe (7pt), smooth interpolation
- Helvetica + Helvetica-Bold (Montserrat substitute, since Helvetica ships with ReportLab and avoids font bundling)
- Times-Roman (Roboto Slab substitute) for body answer text
- "out" on the candidate identity row (not "openly")
- No em dashes, no en dashes; every separator is a middle dot or comma
- Disclaimer on every page: "Paid for by Ohio Pride PAC. Zachary R. Joseph, Director."

## What's Not in This Phase

- Custom Montserrat / Roboto Slab font bundling. We can add this in a small follow-up by including TTF files in the function bundle and registering them with `pdfmetrics.registerFont()`. Helvetica + Times reads professionally and avoids deployment complexity for now.
- Email delivery of the PDF to the candidate or board. That comes in Phase 5 along with the on-INSERT confirmation triggers.
- Background regeneration. Right now the admin clicks Generate PDF manually. Phase 5 can optionally auto-generate on status change to "endorsed".
