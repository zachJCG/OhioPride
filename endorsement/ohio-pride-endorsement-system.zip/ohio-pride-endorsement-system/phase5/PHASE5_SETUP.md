# Phase 5 Setup Notes

## Files

```
/supabase/functions/_shared/types.ts                    (shared TS types)
/supabase/functions/_shared/resend.ts                   (Resend API wrapper)
/supabase/functions/_shared/templates.ts                (HTML + text email builders)
/supabase/functions/on-new-application/index.ts         (Edge Function 1)
/supabase/functions/on-status-endorsed/index.ts         (Edge Function 2)
/supabase/migrations/20260505_endorsement_notification_triggers.sql
```

## Three Things to Set Up Before Deploying

### 1. Resend Account and Verified Domain

1. Create a Resend account at https://resend.com (free tier covers this use case: 3,000 emails/month, 100/day)
2. Verify a sending domain. Recommended: a subdomain like `mail.ohiopride.org` or directly `ohiopride.org`
   - Resend Dashboard → Domains → Add Domain → enter `ohiopride.org`
   - Add the four DNS records Resend provides (one TXT for SPF, three CNAMEs for DKIM, one TXT for DMARC) in your DNS host
   - Wait for verification (usually 5 to 30 minutes)
3. Create an API key
   - Resend Dashboard → API Keys → Create API Key → name it `ohio-pride-pac-prod`, give it Sending access on the verified domain
   - Copy the key (starts with `re_`). You'll only see it once. Store it somewhere secure.
4. Decide on your `From` address. Recommended: `Ohio Pride PAC <screening@ohiopride.org>`. The friendly name lands in inboxes as "Ohio Pride PAC", and screening@ is a real-feeling sender.

### 2. Webhook Shared Secret

Generate a random 40+ character token. On macOS or Linux:

```bash
openssl rand -hex 32
```

Save the resulting string. You'll paste it into two places: Supabase Vault (read by the database trigger) and the Edge Function env vars (read by the function to authenticate the webhook).

### 3. Apply the Trigger Migration

Run the migration SQL in the Supabase SQL editor (or I can apply it via MCP if you say so).

After the migration applies, run this **once** in the SQL editor to create the secret in Vault. Replace the placeholder with your actual secret from step 2:

```sql
select vault.create_secret(
  'PASTE_YOUR_40_CHAR_SECRET_HERE',
  'webhook_secret',
  'Shared secret for endorsement notification webhooks'
);
```

To rotate later:

```sql
select vault.update_secret(
  (select id from vault.secrets where name = 'webhook_secret'),
  'NEW_SECRET'
);
```

## Deploy the Edge Functions

The cleanest path is the Supabase CLI:

```bash
# One-time install (if you don't have it)
brew install supabase/tap/supabase

# Link your local project to the hosted one
supabase link --project-ref dkdxefzhttkmjhdbkvqn

# Deploy both functions
supabase functions deploy on-new-application
supabase functions deploy on-status-endorsed
```

If you'd rather paste the code into the dashboard editor instead, that works too: Edge Functions → Create a new function → name it `on-new-application` → paste `index.ts` → deploy. Repeat for `on-status-endorsed`. The shared files in `_shared/` need to be uploaded as separate files in the same function or copied inline. CLI is simpler for shared code.

I can also deploy these for you via Supabase MCP if you'd prefer; just say the word.

## Set Edge Function Environment Variables

In **Supabase Dashboard → Edge Functions → on-new-application → Settings → Add new secret**, add the same values for both functions:

| Variable | Value |
|---|---|
| `RESEND_API_KEY` | `re_...` from Resend |
| `WEBHOOK_SECRET` | The 40+ char token from step 2 (must match Vault) |
| `FROM_EMAIL` | `Ohio Pride PAC <screening@ohiopride.org>` |
| `ADMIN_EMAIL` | `zach@ohiopride.org` (only needed on `on-new-application`) |
| `ADMIN_DETAIL_BASE_URL` | `https://ohiopride.org/admin/endorsements/detail` (only on `on-new-application`) |

Edge Function secrets are server-only and not exposed to the client.

## How It Flows

### New application flow

```
Candidate submits form
    ↓ (Supabase REST insert)
public.endorsement_applications row created
    ↓ (AFTER INSERT trigger fires)
tg_notify_new_application reads webhook_secret from Vault
    ↓ (pg_net HTTP POST)
Edge Function on-new-application receives the row
    ↓ (verifies Authorization header)
Resend API called twice in parallel
    ↓
Candidate gets confirmation, Director gets alert
```

### Endorsement flow

```
Director changes status to "endorsed" in admin
    ↓ (Supabase REST update)
AFTER UPDATE trigger fires, sees status transition
    ↓ (pg_net HTTP POST, only if status went TO 'endorsed')
Edge Function on-status-endorsed receives the row
    ↓
Candidate gets congratulations email
    ↓
(Auto-publish is implicit: /endorsements page reads live from
 public_endorsements view, so the candidate appears immediately on
 next page load. No build hook or cache purge needed.)
```

## Email Templates

Three branded templates, all with consistent header (pride flag stripe + navy band + wordmark), white content area, navy footer with disclaimer, and bottom pride stripe. They render correctly in Gmail, Apple Mail, and Outlook.

- **Candidate confirmation** (`We received your application | Ohio Pride PAC`) — warm thank-you, four-step "what happens next", reply-to is screening@.
- **Director alert** (`[New Application] {Name} for {Office}`) — terse details + Open in Admin button. Reply-to is set to the candidate's email so you can hit reply and write to them directly from Gmail.
- **Endorsement congratulations** (`Endorsed by Ohio Pride PAC: Welcome to the team`) — green "endorsed" pill, four-step "what happens from here", links to the public page.

Each email also has a plain-text version sent alongside the HTML for accessibility and for clients that prefer text.

## Idempotency

Each email send uses an idempotency key on Resend's side:
- `{application_id}_candidate_confirm`
- `{application_id}_admin_alert`
- `{application_id}_endorsed`

If pg_net retries the webhook for any reason (network blip, Edge Function cold start), Resend will return the same email ID without sending a duplicate.

## Test Plan

After all three setup steps + deployment + env vars are in place:

1. **Test the webhook itself** by submitting a real test application through `/endorsement/screening`. Use a candidate email you control so you receive the confirmation.
2. **Check Edge Function logs** in Supabase Dashboard → Edge Functions → on-new-application → Logs. Look for a 200 response with `candidate_email.ok: true` and `director_alert.ok: true`.
3. **Check Resend dashboard** → Emails. You should see two emails dispatched: one to the candidate, one to your admin email.
4. **Check both inboxes**. The candidate confirmation should arrive within seconds. The director alert should arrive in your inbox.
5. **Test the endorsed flow**: in admin, change the test application's status to "Endorsed" and click Save. Confirm the candidate gets the congratulations email and that the public `/endorsements` page (Phase 6) shows the candidate.
6. **Test idempotency**: trigger the same flow twice in quick succession (e.g., Save → Save again with no changes; or update something else and flip status back and forth). The second attempt should NOT result in duplicate emails because of the idempotency keys and the `OLD.status` check in the trigger.

## Cleanup After Testing

```sql
delete from public.endorsement_applications where email = 'your-test@example.com';
```

## Common Issues

**No email arrives, no log entry** → trigger probably didn't fire. Check that the migration applied (`select * from pg_trigger where tgname like 'trg_notify%';` should return two rows) and that the webhook secret is in Vault (`select name from vault.secrets;` should include 'webhook_secret').

**Edge Function logs show 401 Unauthorized** → the secret in Vault doesn't match the `WEBHOOK_SECRET` env var. Re-check both, paste them fresh.

**Edge Function logs show "RESEND_API_KEY not configured"** → set the env var on both Edge Functions and redeploy if needed.

**Resend dashboard shows "Domain not verified" error** → DNS records haven't propagated. Wait longer or double-check the records in your DNS host.

**Email lands in spam** → expected on the very first sends until your domain warms up. Mark as "not spam" in Gmail. After 10 to 20 emails over a couple of days, deliverability stabilizes. You can also set up a DMARC record `v=DMARC1; p=none; rua=mailto:dmarc@ohiopride.org;` for better reputation.

**Candidate gets duplicate emails** → unlikely with idempotency keys, but if it happens, check the trigger logs in pg_net (`select * from net._http_response order by created desc limit 10;`) and confirm only one HTTP request was sent per submission.

## Brand Compliance

- Pride flag stripe at top (8-10 pt) and bottom (7 pt) of every email
- Navy header band with "OhioPride PAC" wordmark
- Cyan eyebrow tags ("APPLICATION RECEIVED", "NEW APPLICATION", "ENDORSED")
- Helvetica/Arial for headlines, Georgia for body (web-safe; no Google Font dependency)
- Numbered lists use cyan numerals, not bullets
- All copy avoids em dashes and en dashes; uses periods and commas instead
- "out" used in the "Are you out as LGBTQ+?" question on the form (not "openly")
- Footer disclaimer on every email: "Paid for by Ohio Pride PAC. Zachary R. Joseph, Director."
- Director sign-off: "Zachary R. Joseph / Director, Ohio Pride PAC"
