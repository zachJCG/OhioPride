# Phase 6 Setup Notes

## File

```
/endorsements/index.html
```

Drop into the matching path in your Netlify repo.

## Configuration

Single value to fill in: the `SUPABASE_ANON_KEY` placeholder near the top of the inline script. Same key as Phase 2 and Phase 3. Paste once and ship.

```javascript
const CONFIG = {
  SUPABASE_URL:      'https://dkdxefzhttkmjhdbkvqn.supabase.co',
  SUPABASE_ANON_KEY: '__PASTE_SUPABASE_ANON_KEY__',
  SCREENING_PATH:    '/endorsement/screening'
};
```

The anon key is public by design. It only grants read access to rows in `public_endorsements` (which is the safe view filtered to `status = 'endorsed'`). Internal fields like email, phone, reviewer notes, and conflict disclosures are never exposed to anon. They aren't in the view at all.

## What's Wired Up

- Live data fetch from the `public_endorsements` view (no caching, fresh on every page load)
- Sorted by election year descending, then candidate name alphabetically
- Filter chips: All / Federal / State / Local with live count badges
- Year dropdown: auto-populated from the actual data
- Empty states for both "no endorsements yet" and "no matches with current filters"
- Skeleton loader cards while the fetch is in flight
- CTA banner at the bottom linking to `/endorsement/screening`
- Footer with disclaimer

## How Auto-Publish Works

The `public_endorsements` view does the publishing automatically. As soon as you flip a row to `status = 'endorsed'` in the admin dashboard, the candidate appears on the public page on the next load. No build hook, no cache purge, no manual refresh.

This is intentional and matches the architecture from Phases 1 through 5:

```
Director clicks "Endorsed" in admin
    ↓ (REST update via service role -> RLS allows admin)
Row's status flips to 'endorsed'
    ↓
Now visible to anon via public_endorsements view
    ↓
Phase 6 page picks it up on next fetch
    ↓
Phase 5 trigger separately fires the congratulations email
```

## How Office Levels Are Classified

Since we don't store `office_level` as a separate column, the page derives it from the `office_sought` text using regex matching. The rules:

- **Federal**: matches "U.S.", "United States", "Congress", "President", or "Federal"
- **State**: matches "Ohio Senate/House/Statehouse", "State Senate/House/Representative/Senator", "Governor", "Attorney General", "Secretary of State", "State Treasurer/Auditor", or "Supreme Court" with Ohio context
- **Local**: everything else (default)

Examples:
- `Ohio House of Representatives` → State
- `U.S. Senate` → Federal
- `Mayor of Akron` → Local
- `Cleveland City Council` → Local
- `Ohio Supreme Court Justice` → State
- `Township Trustee` → Local

If you find an office that's misclassified once you have real candidates, the regex block is in the `classifyOffice()` function at the top of the inline script. Easy to tweak.

A future improvement is adding an `office_level` column to the schema and setting it explicitly. Not needed for v1.

## What Anon Can See on This Page

From `public_endorsements` view (defined in Phase 1):

- `id`
- `candidate_name`
- `pronouns`
- `office_sought`
- `district`
- `election_year`
- `party`
- `website`
- `bio`
- `is_out` (collected but not currently displayed on cards)
- `endorsed_at` (= updated_at from when the row was last touched)

What anon CAN'T see:

- Email, phone, committee, treasurer
- All 5 core position responses
- All open responses
- Conflicts disclosure
- Reviewer notes
- Attestation, signature
- Submission metadata

This split is enforced by RLS at the database level, not by the page code. Even if someone tried a direct query against the table, they'd only get the limited columns and only for endorsed rows.

## Privacy Note: is_out Field

The form asks "Are you out as LGBTQ+?" with three options (yes / no / prefer not to say). The view exposes this to anon for endorsed candidates, but the current card design intentionally does NOT display it. We collect the data for internal context only.

If you later decide to show an "Out as LGBTQ+" pill on cards, only show it when `is_out === 'yes'`. Never show anything for `'no'` or `'prefer_not_to_say'`. A "no" or absent badge could be inferred as someone being closeted, which would be a serious harm.

## Test Plan

After deploying:

1. **Visit `/endorsements`** with no endorsed candidates → should show "Endorsements coming soon" empty state with a CTA to the screening form.
2. **Manually flip a test application's status to 'endorsed'** in the admin (or via SQL: `update public.endorsement_applications set status = 'endorsed' where email = 'test@example.com';`).
3. **Refresh `/endorsements`** → the test candidate should appear in the grid.
4. **Click filter chips** → counts update; switching to a level with no matches shows the "No matches" empty state with a "Clear filters" button.
5. **Click "Visit Campaign Site"** → opens the candidate's website in a new tab.
6. **Resize the window down to mobile width** → cards stack to single column, chips become horizontally scrollable, CTA stacks vertically.
7. **Open DevTools network tab** → confirm only one `public_endorsements` query is made per page load.
8. **Try direct SQL bypass** in the browser console:
   ```js
   const c = supabase.createClient(...);
   const { data } = await c.from('endorsement_applications').select('email,reviewer_notes');
   ```
   Should return zero rows for non-endorsed and only `null`-filled emails/notes for endorsed (because the table policy returns rows but they aren't in the view, and this query targets the table directly). The point: sensitive fields are never exposed.

## Cleanup After Testing

```sql
-- Reset any test applications back to 'submitted' or delete them
delete from public.endorsement_applications where email = 'test@example.com';
```

## Brand Compliance

- Navy #0F2233 dominant (header, hero, CTA banner, footer)
- Light Blue #73D7EE for eyebrows, "Endorsed" badges, focus rings, CTA button on the navy banner
- Pride gradient on top stripe (14px), bottom stripe (10px), top of each card (4px), top of CTA banner (4px)
- Montserrat for headlines, eyebrows, buttons, names
- Roboto Slab for body, office names, bio text
- "out" used in code comments and the privacy note above (not "openly")
- No em dashes or en dashes
- Footer disclaimer: "Paid for by Ohio Pride PAC. Zachary R. Joseph, Director."
- Tagline echoed in the hero: "Endorse. Mobilize. Fight for Ohio."
