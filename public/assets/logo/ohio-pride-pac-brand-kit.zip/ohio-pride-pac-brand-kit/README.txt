OHIO PRIDE PAC BRAND KIT
https://www.ohiopride.org/brand

Everything in this archive is the current (v2.0) Ohio Pride PAC mark.
A machine-readable index of every file is in manifest.json.

WHICH FILE
  Dark backgrounds   wordmark-primary-transparent.*      (white + light blue)
  Light backgrounds  wordmark-primary-dark-transparent.* (navy + light blue)
  Single color       wordmark-mono-white-transparent.*   or wordmark-mono-navy-transparent.*
  Profile pictures   lockup-primary-on-navy-1024.png
  Cover photos       banner-primary-on-navy-2400.jpg
  Print              the .pdf files are vector; the .ai files are the editable sources

FORMATS
  .svg  vector, web and design tools      .pdf  vector, print
  .png  transparent raster                .webp transparent raster, smaller, web
  .jpg  flattened on navy or white, for uploads that refuse transparency

COLORS
  Navy        #152233      Light Blue  #70D6EC      White  #FFFFFF
  Progress Pride accent: #E40303 #FFBC00 #FFED00 #008026 #004DFF #750787 #000000 #613915 #FFAFC8

TYPE
  Montserrat (headlines, wordmark)   Roboto Slab (body)   both on Google Fonts

RULES
  Keep clear space equal to the height of the O in OHIO on every side.
  Minimum width 140px on screen, 1.25in in print; below that use the favicon mark.
  Never recolor, stretch, rotate, add effects, or fill the mark with the rainbow.
  The "Endorsed by" badge is for candidates Ohio Pride PAC has endorsed on the record. Nothing else.

Questions: info@ohiopride.org
