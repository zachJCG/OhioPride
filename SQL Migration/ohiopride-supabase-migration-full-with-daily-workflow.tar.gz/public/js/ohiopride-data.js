/* =============================================================================
 * Ohio Pride PAC — Data Client (consolidated through Round 3)
 * -----------------------------------------------------------------------------
 * Thin client-side helper for fetching dynamic data from Netlify functions
 * that sit in front of Supabase. Single file covering every Supabase-backed
 * surface on the public website through Round 3.
 *
 *   OhioPride.loadProgress(fillSel, textSel)
 *       Fills the founding-member progress bar and the count label.
 *
 *   OhioPride.loadBoard(gridSel)
 *       Renders the board grid from board_members.
 *
 *   OhioPride.loadFoundingMemberTiers(gridSel)
 *       Renders the five tier-legend cards on /founding-members.
 *
 *   OhioPride.loadPublicMembers(listSel)
 *       Renders the tier-grouped public member list on /founding-members.
 *
 *   OhioPride.loadSiteLeadership(options)
 *       Fills disclaimer and directors elements from site_leadership.
 *
 *   OhioPride.loadBills(containerSel, options)   <- Round 3
 *       Fetches the full bill tracker data and hands it to the existing
 *       billCardHTML() and renderPipeline() functions on /issues. Does
 *       NOT duplicate rendering logic; acts purely as a data source.
 *
 * Design principles:
 *   - No framework. Plain fetch + DOM.
 *   - Fail open: if a fetch errors, whatever the server-rendered HTML
 *     already contained stays visible.
 *   - Reuse existing rendering functions where they exist rather than
 *     reimplementing them here.
 * ============================================================================= */

(function () {
  'use strict';

  // -----------------------------------------------------------------------
  // Endpoint registry.
  // -----------------------------------------------------------------------
  var ENDPOINTS = {
    progress:               '/.netlify/functions/founding-members-progress',
    board:                  '/.netlify/functions/board-members',
    foundingMemberTiers:    '/.netlify/functions/founding-member-tiers',
    publicMembers:          '/.netlify/functions/public-members',
    siteLeadership:         '/.netlify/functions/site-leadership',
    bills:                  '/.netlify/functions/bills',
    scorecard:              '/.netlify/functions/scorecard',
  };

  // -----------------------------------------------------------------------
  // Utilities
  // -----------------------------------------------------------------------
  function getJson(url) {
    return fetch(url, {
      credentials: 'omit',
      headers: { accept: 'application/json' },
    }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    });
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
  var escapeAttr = escapeHtml;

  // -----------------------------------------------------------------------
  // Progress bar (Round 1)
  // -----------------------------------------------------------------------
  function loadProgress(fillSelector, textSelector) {
    var bar  = document.querySelector(fillSelector);
    var text = textSelector ? document.querySelector(textSelector) : null;
    if (!bar) return;

    getJson(ENDPOINTS.progress)
      .then(function (data) {
        if (!data || !data.ok) return;
        var pct = Math.min(data.percent_to_goal, 100);

        var observer = new IntersectionObserver(function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              bar.style.transition = 'width 1.5s cubic-bezier(0.4, 0, 0.2, 1)';
              bar.style.width = pct + '%';
              observer.unobserve(entry.target);
            }
          });
        }, { threshold: 0.3 });

        observer.observe(bar.parentElement || bar);

        if (text) {
          text.textContent = data.member_count.toLocaleString() +
            ' of ' + data.goal.toLocaleString() + ' Founding Members';
        }
      })
      .catch(function () { /* fail open */ });
  }

  // -----------------------------------------------------------------------
  // Board grid (Round 1)
  // -----------------------------------------------------------------------
  function loadBoard(gridSelector) {
    var grid = document.querySelector(gridSelector);
    if (!grid) return;

    var chipLabelByClass = {
      'is-director':  'Director',
      'is-treasurer': 'Treasurer',
      'is-secretary': 'Secretary',
      'is-comms':     'Comms Director',
    };

    getJson(ENDPOINTS.board)
      .then(function (data) {
        if (!data || !data.ok || !Array.isArray(data.members)) return;
        grid.innerHTML = '';

        data.members.forEach(function (m, i) {
          var card = document.createElement('article');
          card.className = 'board-card reveal';
          card.style.transitionDelay = (Math.min(i, 6) * 0.05) + 's';

          var chipHtml = '';
          if (m.chip && chipLabelByClass[m.chip]) {
            chipHtml = '<span class="board-card-chip ' + m.chip + '">' +
                       chipLabelByClass[m.chip] + '</span>';
          }

          var bioParagraphs = Array.isArray(m.bio) ? m.bio : [];
          var bioHtml = bioParagraphs
            .map(function (p) { return '<p>' + escapeHtml(p) + '</p>'; })
            .join('');

          card.innerHTML =
            '<div class="board-card-photo">' +
              (m.img_path
                ? '<img src="' + escapeAttr(m.img_path) + '" alt="' + escapeAttr(m.name) + '" loading="lazy">'
                : '<div class="board-card-photo-placeholder" aria-hidden="true"></div>') +
            '</div>' +
            '<div class="board-card-body">' +
              chipHtml +
              '<h3 class="board-card-name">' + escapeHtml(m.name) + '</h3>' +
              '<p class="board-card-role">' + escapeHtml(m.role || 'Board Member') + '</p>' +
              '<div class="board-card-bio">' + bioHtml + '</div>' +
            '</div>';

          grid.appendChild(card);
        });
      })
      .catch(function () { /* fail open */ });
  }

  // -----------------------------------------------------------------------
  // Founding-member tier cards (Round 2)
  // -----------------------------------------------------------------------
  function loadFoundingMemberTiers(gridSelector) {
    var grid = document.querySelector(gridSelector);
    if (!grid) return;

    getJson(ENDPOINTS.foundingMemberTiers)
      .then(function (data) {
        if (!data || !data.ok || !Array.isArray(data.tiers)) return;

        grid.innerHTML = data.tiers.map(function (t) {
          return (
            '<div class="tier-legend-card" data-slug="' + escapeAttr(t.slug) + '">' +
              '<div class="tier-name">' + escapeHtml(t.name) + '</div>' +
              '<div class="tier-price">' + escapeHtml(t.amount_display) + '</div>' +
            '</div>'
          );
        }).join('');
      })
      .catch(function () { /* fail open */ });
  }

  // -----------------------------------------------------------------------
  // Public member list grouped by tier (Round 2)
  // -----------------------------------------------------------------------
  function loadPublicMembers(listSelector) {
    var list = document.querySelector(listSelector);
    if (!list) return;

    getJson(ENDPOINTS.publicMembers)
      .then(function (data) {
        if (!data || !data.ok || !Array.isArray(data.groups)) return;

        if (data.groups.length === 0) {
          list.style.display = 'none';
          return;
        }
        list.style.display = '';

        list.innerHTML = data.groups.map(function (group) {
          var rows = group.members.map(function (m) {
            return (
              '<div class="member-row">' +
                '<div class="member-name">' + escapeHtml(m.display_name) + '</div>' +
              '</div>'
            );
          }).join('');

          return (
            '<div class="tier-group">' +
              '<div class="tier-group-header">' +
                '<div class="tier-group-title">' + escapeHtml(group.tier) + '</div>' +
              '</div>' +
              rows +
            '</div>'
          );
        }).join('');
      })
      .catch(function () { /* fail open */ });
  }

  // -----------------------------------------------------------------------
  // Site leadership / disclaimer (Round 2)
  // -----------------------------------------------------------------------
  function loadSiteLeadership(options) {
    options = options || {};
    var entity = options.entity || 'pac';

    getJson(ENDPOINTS.siteLeadership + '?entity=' + encodeURIComponent(entity))
      .then(function (data) {
        if (!data || !data.ok) return;

        document.querySelectorAll('[data-ohp-disclaimer]').forEach(function (el) {
          var wantedEntity = el.getAttribute('data-ohp-entity') || 'pac';
          if (wantedEntity === entity) {
            el.textContent = data.disclaimer;
          }
        });

        document.querySelectorAll('[data-ohp-directors]').forEach(function (el) {
          var wantedEntity = el.getAttribute('data-ohp-entity') || 'pac';
          if (wantedEntity !== entity) return;

          var html = data.officers.map(function (o) {
            return '<strong>' + escapeHtml(o.title) + ':</strong> ' + escapeHtml(o.full_name);
          }).join('<br>');
          el.innerHTML = html;
        });
      })
      .catch(function () { /* fail open */ });
  }

  // -----------------------------------------------------------------------
  // Bill tracker (Round 3)
  // -----------------------------------------------------------------------
  //
  // The issues page has existing functions `billCardHTML(bill)` and
  // `renderPipeline(container, chamber, step, options)` that do all of the
  // visual work. This loader does three things and nothing more:
  //
  //   1. Fetches the bill data from Supabase via /.netlify/functions/bills
  //   2. Adapts each DB record into the shape billCardHTML() expects
  //      (translates e.g. status.color_hex -> statusColor, categories
  //      array -> categoryLabels array, etc.)
  //   3. Hands the adapted list to the existing renderBills() function on
  //      the page, or renders directly if renderBills is not defined.
  //
  // Keeping rendering logic in the HTML file means designers can adjust
  // the card markup without touching this JS file.
  // -----------------------------------------------------------------------
  function adaptBillRowForRendering(row) {
    // Turn the relational shape returned by bills_public into the flat
    // shape billCardHTML() expects. Keep this function small and explicit
    // so the mapping is auditable at a glance.
    var status = row.status || {};
    var categories = Array.isArray(row.categories) ? row.categories : [];

    return {
      // Identity
      id:             row.slug,            // the page uses `b.id` for DOM IDs
      bill:           row.bill_number,
      title:          row.title,
      nickname:       row.nickname || '',
      officialTitle:  row.official_title,

      // Editorial
      stance:         row.stance,

      // Status
      status:         status.slug,
      statusLabel:    status.label,
      statusColor:    status.color_hex,

      // Categories: billCardHTML expects two parallel arrays — slugs in
      // `categories` for the data-attribute, labels in `categoryLabels`
      // for the visible badges. We provide both from the same source so
      // they stay in sync.
      categories:       categories.map(function (c) { return c.slug; }),
      categoryLabels:   categories.map(function (c) { return c.label; }),

      // Pipeline
      chamber:        row.chamber,
      currentStep:    row.current_step_index,
      pipelineDates:  row.pipeline_dates || {},

      // Narrative
      description:    row.description,
      sponsors:       row.sponsors,
      lastAction:     row.last_action,
      nextDate:       row.next_date || '',
      houseVote:      row.house_vote || '',

      // Links
      url:              row.internal_url || ('/issues/' + row.slug),
      legislatureUrl:   row.legislature_url,
      textUrl:          row.text_url || '',
    };
  }

  function loadBills(containerSelector, options) {
    options = options || {};
    var container = document.querySelector(containerSelector);
    if (!container) return;

    getJson(ENDPOINTS.bills)
      .then(function (data) {
        if (!data || !data.ok || !Array.isArray(data.bills)) return;

        // Adapt database records to the shape the existing render code
        // expects, and expose on window.BILLS so any other script on the
        // page that references the global (filter buttons, stats tiles,
        // detail-page lookups) keeps working unchanged.
        var adapted = data.bills.map(adaptBillRowForRendering);
        window.BILLS = adapted;

        // If the page defines a renderBills function (as /issues does),
        // call it. Otherwise fall back to calling billCardHTML directly
        // and joining the output.
        if (typeof window.renderBills === 'function') {
          window.renderBills(adapted);
        } else if (typeof window.billCardHTML === 'function') {
          container.innerHTML = adapted.map(window.billCardHTML).join('');
        } else {
          // Last-resort fallback when neither helper is defined. Renders
          // a minimal card without CSS classes — shouldn't happen on the
          // real /issues page, but keeps things graceful on, say, a
          // standalone preview.
          container.innerHTML = adapted.map(function (b) {
            return '<div class="bill-card-fallback">' +
                   '<strong>' + escapeHtml(b.bill) + ':</strong> ' +
                   escapeHtml(b.title) +
                   '</div>';
          }).join('');
        }

        // Update the stats tiles if they exist on the page. We compute
        // these client-side from the loaded bill list rather than from
        // a separate endpoint because the data is already in memory.
        updateBillStats(adapted);

        // Update the "Last Updated" card on the /issues page. Uses
        // MAX(updated_at) across the raw bill rows (before adaptation,
        // since the adapter does not preserve updated_at).
        updateBillsLastUpdated(data.bills);

        // Fire a custom event so other scripts on the page (filter
        // buttons, category pickers) can re-initialize against the
        // newly-loaded data. This is a small integration seam that
        // avoids tight coupling between loader and UI behavior.
        var evt;
        try {
          evt = new CustomEvent('ohp:bills-loaded', { detail: { bills: adapted } });
        } catch (_e) {
          // IE11-safe fallback, in case it ever matters. Harmless on modern browsers.
          evt = document.createEvent('CustomEvent');
          evt.initCustomEvent('ohp:bills-loaded', false, false, { bills: adapted });
        }
        document.dispatchEvent(evt);

        // Post-render hook for the pipeline visualization. Each bill card
        // has a <div id="pipeline-${b.id}"></div> placeholder; we populate
        // each one via the existing renderPipeline function from
        // /js/bill-pipeline.js.
        if (typeof window.renderPipeline === 'function') {
          adapted.forEach(function (b) {
            var target = document.getElementById('pipeline-' + b.id);
            if (target) {
              window.renderPipeline(target, b.chamber, b.currentStep, {
                size:  options.pipelineSize || 'sm',
                dates: b.pipelineDates,
              });
            }
          });
        }
      })
      .catch(function () { /* fail open */ });
  }

  function updateBillStats(bills) {
    // Count bills that are either in a post-committee phase or explicitly
    // marked with a "passed" status. This mirrors the logic the hardcoded
    // numbers on the current /issues page were expressing.
    var passedCount = 0;
    var committeeCount = 0;
    bills.forEach(function (b) {
      var s = (b.status || '').toLowerCase();
      if (s.indexOf('passed') === 0 || s === 'signed-into-law' || s === 'enrolled') {
        passedCount += 1;
      }
      if (s === 'in-committee' || s === 'passed-committee' || s === 'introduced') {
        committeeCount += 1;
      }
    });

    var elPassed    = document.getElementById('statPassed');
    var elCommittee = document.getElementById('statCommittee');
    if (elPassed)    elPassed.textContent    = String(passedCount);
    if (elCommittee) elCommittee.textContent = String(committeeCount);
  }

  // -----------------------------------------------------------------------
  // Last-updated timestamp for the issues page header card. Derived from
  // MAX(updated_at) across the fetched rows so we never need a separate
  // endpoint or a separate query. Falls back silently if either the
  // timestamp is missing or the target elements are not on the page.
  //
  // The two source elements (lastUpdatedDate, lastUpdatedTime) already
  // exist in the /issues HTML; we just populate them with human-readable
  // date and time strings formatted in US Eastern time, which matches the
  // convention the hand-maintained LAST_UPDATED constant was using.
  // -----------------------------------------------------------------------
  function updateBillsLastUpdated(rawBillRows) {
    if (!Array.isArray(rawBillRows) || rawBillRows.length === 0) return;

    var maxTs = null;
    rawBillRows.forEach(function (row) {
      if (row && row.updated_at) {
        var ts = Date.parse(row.updated_at);
        if (!isNaN(ts) && (maxTs === null || ts > maxTs)) {
          maxTs = ts;
        }
      }
    });

    if (maxTs === null) return;

    var d = new Date(maxTs);

    // Build date and time strings in US/Eastern, using the same visual
    // format the hardcoded LAST_UPDATED was using ("04/20/26" and
    // "05:35 PM EDT"). Intl.DateTimeFormat handles DST transitions
    // automatically so the "EDT" vs "EST" suffix is always correct.
    var dateFmt = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/New_York',
      year: '2-digit', month: '2-digit', day: '2-digit',
    });
    var timeFmt = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/New_York',
      hour: '2-digit', minute: '2-digit',
      hour12: true, timeZoneName: 'short',
    });

    var dateStr = dateFmt.format(d);
    var timeStr = timeFmt.format(d);

    var dateEl = document.getElementById('lastUpdatedDate');
    var timeEl = document.getElementById('lastUpdatedTime');
    if (dateEl) dateEl.textContent = dateStr;
    if (timeEl) timeEl.textContent = timeStr;
  }

  // -----------------------------------------------------------------------
  // Scorecard (Round 4)
  //
  // The /scorecard page has substantial inline rendering logic that
  // expects several globals to be set before it runs: HOUSE_MEMBERS and
  // SENATE_MEMBERS arrays, the GRADE_SCALE array, the SCORED_BILLS
  // reference list, and the SCORECARD_UPDATED constant. The integration
  // strategy is to shape the Supabase response into exactly those
  // shapes, then let the existing rendering code run unchanged.
  //
  // Why this approach: the migration risk surface is smallest when only
  // the data source changes. The page's visual rendering, filter
  // behavior, and card expand/collapse logic all stay identical. If
  // something goes wrong, it goes wrong in the loader, not in 200 lines
  // of perfectly-working rendering code.
  //
  // The adapter translates between two naming conventions: the
  // database uses full names (votes_score, sponsorship_score,
  // news_score, full_name, district, chamber in lower case) while the
  // inline rendering expects short names (v, s, n, name, d, chamber
  // title-cased) because that's what the JS source files have used
  // historically. The mapping is explicit at the top of the function
  // so it's easy to audit.
  // -----------------------------------------------------------------------
  function loadScorecard(options) {
    options = options || {};

    getJson(ENDPOINTS.scorecard)
      .then(function (data) {
        if (!data || !data.ok) return;

        // ---- Translate legislators to the shape HOUSE_MEMBERS /
        // SENATE_MEMBERS have historically used. The existing inline
        // rendering reads `m.d`, `m.name`, `m.party`, `m.v`, `m.s`,
        // `m.n`, `m.notes`, and `m.chamber` (with chamber being
        // title-cased: "House" or "Senate"). We produce exactly that
        // shape so renderCards() works without modification.
        function adaptLegislator(row) {
          var chamberTitleCase = row.chamber === 'senate' ? 'Senate' : 'House';
          return {
            // Core identity + scoring (short names to match legacy)
            d:       row.district,
            name:    row.full_name,
            party:   row.party,
            v:       row.votes_score,
            s:       row.sponsorship_score,
            n:       row.news_score,
            notes:   row.notes || '',

            // Derived (already computed server-side via calc_score /
            // calc_grade; we pass them through rather than recomputing)
            chamber: chamberTitleCase,
            score:   row.score,
            grade:   {
              grade: row.grade ? row.grade.grade     : 'F',
              label: row.grade ? row.grade.label     : 'Hostile',
              color: row.grade ? row.grade.color_hex : '#dc2626',
            },

            // Preserve metadata the rendering code might use in the
            // future. Harmless today; no existing reader references these.
            leadership_role: row.leadership_role,
            updated_at:      row.updated_at,
          };
        }

        var legislators = (data.legislators || []).map(adaptLegislator);

        // Split into the two arrays the page expects. Use window
        // assignments so the inline script (which runs after this
        // function resolves) picks up the values.
        window.HOUSE_MEMBERS  = legislators.filter(function (m) { return m.chamber === 'House'; });
        window.SENATE_MEMBERS = legislators.filter(function (m) { return m.chamber === 'Senate'; });

        // ---- Translate grade_scale. The inline rendering expects
        // GRADE_SCALE with fields { min, grade, label, color } — we
        // have { min_score, grade, label, color_hex }. One small rename.
        window.GRADE_SCALE = (data.grade_scale || []).map(function (g) {
          return {
            min:   g.min_score,
            grade: g.grade,
            label: g.label,
            color: g.color_hex,
          };
        });

        // ---- SCORECARD_UPDATED: the page renders "Last updated X at
        // Y" using this object. Derive from data.updated_at, formatted
        // in US Eastern time to match the hand-maintained convention.
        if (data.updated_at) {
          var d = new Date(data.updated_at);
          var dateFmt = new Intl.DateTimeFormat('en-US', {
            timeZone: 'America/New_York',
            year: '2-digit', month: '2-digit', day: '2-digit',
          });
          var timeFmt = new Intl.DateTimeFormat('en-US', {
            timeZone: 'America/New_York',
            hour: '2-digit', minute: '2-digit',
            hour12: true, timeZoneName: 'short',
          });
          window.SCORECARD_UPDATED = {
            date: dateFmt.format(d),
            time: timeFmt.format(d),
          };
        } else {
          window.SCORECARD_UPDATED = { date: '', time: '' };
        }

        // ---- calcScore and calcGrade: the inline code calls these as
        // functions on individual member objects. Since we already
        // computed score and grade server-side and attached them to
        // each legislator, our versions of these helpers just read the
        // stored values. This keeps the inline rendering code compatible
        // while ensuring the authoritative score/grade come from the
        // calc_score() and calc_grade() SQL functions.
        if (typeof window.calcScore !== 'function') {
          window.calcScore = function (member) {
            // Fallback: mirror the JS logic if for some reason member
            // doesn't have a pre-computed score.
            if (typeof member.score === 'number') return member.score;
            var raw = (member.v || 0) + (member.s || 0) + (member.n || 0);
            return Math.max(0, Math.min(100, Math.round(50 + raw * 5)));
          };
        }
        if (typeof window.calcGrade !== 'function') {
          window.calcGrade = function (score) {
            var scale = window.GRADE_SCALE || [];
            for (var i = 0; i < scale.length; i++) {
              if (score >= scale[i].min) return scale[i];
            }
            return scale[scale.length - 1] || { grade: 'F', label: 'Hostile', color: '#dc2626' };
          };
        }

        // Fire a custom event so any deferred initialization on the
        // page can kick off once the data is ready. Follows the same
        // pattern as ohp:bills-loaded on the issues page.
        var evt;
        try {
          evt = new CustomEvent('ohp:scorecard-loaded', { detail: { data: data } });
        } catch (_e) {
          evt = document.createEvent('CustomEvent');
          evt.initCustomEvent('ohp:scorecard-loaded', false, false, { data: data });
        }
        document.dispatchEvent(evt);
      })
      .catch(function () { /* fail open */ });
  }

  // -----------------------------------------------------------------------
  // Expose
  // -----------------------------------------------------------------------
  window.OhioPride = window.OhioPride || {};
  window.OhioPride.loadProgress             = loadProgress;
  window.OhioPride.loadBoard                = loadBoard;
  window.OhioPride.loadFoundingMemberTiers  = loadFoundingMemberTiers;
  window.OhioPride.loadPublicMembers        = loadPublicMembers;
  window.OhioPride.loadSiteLeadership       = loadSiteLeadership;
  window.OhioPride.loadBills                = loadBills;
  window.OhioPride.loadScorecard            = loadScorecard;
})();
