# Round 3 HTML Swap Instructions for `/issues.html`

This document shows the exact edits needed on `/issues.html` to move the bill tracker from hardcoded JavaScript arrays to the Supabase-backed system deployed in Round 3. The issues page edit is more surgical than the earlier rounds because the page has a lot of inline rendering logic that we want to keep, and only the data source changes.

## What changes and what stays

Three things change on the page. First, the reference to `/js/bill-data.js` is removed because that file's only export (the `BILLS` array and the `LAST_UPDATED` constant) is now served by the Netlify function. Second, the reference to `/js/ohiopride-data.js` is added so the loader is available. Third, the inline script block at the bottom of the page that calls `renderBills(BILLS)` and populates the Last Updated card from `LAST_UPDATED` is replaced with a single call to `OhioPride.loadBills('#billsContainer')`, which does the equivalent work against live data.

Three things deliberately stay exactly as they are. The inline `billCardHTML(b)` function that produces the HTML for each bill card stays, because `loadBills` calls it by name. The inline `renderBills(list)` function that handles the stance grouping and pipeline rendering stays, because `loadBills` calls it by name. And the filter-button wiring that reads `activeStance`, `activeStatus`, and `activeCategory` stays, because it operates against the `window.BILLS` global that the loader populates.

This is the whole point of the client-side rendering approach I walked through when building the Netlify function: by keeping the visual rendering in the HTML file and only changing the data source, we get a migration that's verifiable by eye. If you load `/issues` after the swap and the bills look different, the swap was done incorrectly; if they look identical to before, you can be confident the change was clean.

## Step-by-step edits

### Edit 1: Update the script tags near the bottom of the page

Find the block of script tags around line 774-777 of the current `/issues.html`. It currently reads:

```html
<script src="/js/main.js" defer></script>
<script src="/js/bill-data.js"></script>
<script src="/js/bill-pipeline.js"></script>
<script src="/js/enhancements.js" defer></script>
```

Replace it with:

```html
<script src="/js/main.js" defer></script>
<script src="/js/bill-pipeline.js"></script>
<script src="/js/ohiopride-data.js" defer></script>
<script src="/js/enhancements.js" defer></script>
```

Two changes here: the `<script src="/js/bill-data.js">` tag is removed because that file's data now comes from Supabase, and the `<script src="/js/ohiopride-data.js">` tag is added because the loader it exposes is what the page now uses to fetch bills. The `bill-pipeline.js` tag stays because the loader delegates pipeline rendering to the `renderPipeline` function defined in that file.

### Edit 2: Replace the bottom-of-page initialization block

Find the initialization block around lines 936-945. It currently reads:

```javascript
renderBills(BILLS);
updateStats(BILLS);

// Populate the Last Updated card from LAST_UPDATED in bill-data.js
if (typeof LAST_UPDATED !== "undefined") {
  const dateEl = document.getElementById("lastUpdatedDate");
  const timeEl = document.getElementById("lastUpdatedTime");
  if (dateEl) dateEl.textContent = LAST_UPDATED.date;
  if (timeEl) timeEl.textContent = LAST_UPDATED.time;
}
```

Replace the whole block with:

```javascript
// Fetch bills from Supabase. The loader populates window.BILLS with
// adapted records, calls renderBills() and updateStats() internally,
// and also updates the Last Updated card from MAX(updated_at) across
// the fetched rows.
OhioPride.loadBills('#billsContainer');
```

The single line replaces all three pieces of initialization because the loader handles bill rendering, stats updates, and the Last Updated timestamp internally.

### Edit 3 (optional but recommended): Re-apply filters after the loader finishes

The filter buttons near line 918 work by reading from `window.BILLS` and filtering it. Today they read against the hardcoded `BILLS` array that was available at script parse time. After the migration, `window.BILLS` is populated asynchronously when the fetch resolves, so the filter buttons need to know when the data is ready. The loader dispatches a custom event `ohp:bills-loaded` for exactly this purpose.

If the filter buttons feel unresponsive immediately after page load (clicking them before the fetch resolves does nothing), add this listener just after the loader call in edit 2:

```javascript
document.addEventListener('ohp:bills-loaded', function () {
  // Re-apply whatever filter state was selected so the filter buttons
  // work correctly even if the user clicked one before the fetch finished.
  if (typeof applyFilters === 'function') applyFilters();
});
```

In practice, the fetch resolves in well under a second, so most users will never click a filter button during the load window and this listener is a belt-and-suspenders addition. I recommend including it anyway because the cost is four lines and the robustness is real.

### Edit 4 (delete `/js/bill-data.js` from the repo)

Once you have verified the migration works end-to-end by loading `/issues` and confirming all 22 bills appear with the right filters, colors, pipeline steps, and timestamps, delete the `js/bill-data.js` file from the repository. Leaving it in place is harmless (nothing references it after the above edits), but deletion is cleaner and prevents confusion later when someone looks at the file and wonders whether they should edit it.

## Verification checklist

After deploying the three edits above, load `/issues` in a browser and confirm the following. Every item corresponds to a specific behavior that would be broken if the swap went wrong, so they make good smoke tests.

The page shows 22 bill cards in three stance-grouped sections (anti, mixed, pro). The counts in the section headers add up to 22. The bill cards have the expected status badges in the expected colors. The category badges below the titles show the right color for each category. The pipeline visualization below each bill's description renders with the correct current step highlighted. The filter buttons at the top respond to clicks and the filtered counts update correctly. The Last Updated card in the stats row shows a date and time close to when you last made a bill edit in Supabase (typically within the last hour if nothing has changed recently). Expanding and collapsing bill cards works. Clicking a bill card navigates to `/issues/<slug>`.

If any of those fail, the most likely cause is one of two things. First, the `loadBills` call is firing before `billCardHTML` and `renderBills` are defined, which happens if you put the loader invocation above the inline functions in the HTML. Fix by moving the loader call to the bottom of the inline script. Second, the Netlify function is returning an error or empty result, which you can check by visiting `/.netlify/functions/bills` directly in the browser; it should return a JSON object with 22 bills.
