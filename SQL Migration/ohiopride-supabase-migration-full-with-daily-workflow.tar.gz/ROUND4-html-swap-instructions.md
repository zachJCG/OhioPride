# Round 4 HTML Swap Instructions for `/scorecard.html`

This document shows the exact edits needed on `/scorecard.html` to move the legislative scorecard from hardcoded JavaScript arrays to the Supabase-backed system deployed in Round 4. The scorecard page has more complex rendering logic than the issues page, but the migration pattern is the same: the page's existing rendering code stays exactly as it is, and only the data source changes.

## What changes and what stays

Three things change. The reference to `/js/scorecard-data.js` is removed because that file's only exports (`HOUSE_MEMBERS`, `SENATE_MEMBERS`, `GRADE_SCALE`, `SCORED_BILLS`, `SCORECARD_UPDATED`, and the helper functions `calcScore` and `calcGrade`) are now provided by the loader. The reference to `/js/ohiopride-data.js` is added so the loader is available. And a call to `OhioPride.loadScorecard()` is added at the top of the page's inline initialization block, so the data loads before the rendering code runs.

Everything else stays untouched. The `renderCards()` function that builds each legislator card, the filter logic that reads from `HOUSE_MEMBERS` and `SENATE_MEMBERS`, the grade table rendering, the stats tile updates, the card expand/collapse behavior — all of it keeps working because the loader populates the same globals the page already expects. This is the integration principle I walked through when building the loader: change only the data source, never the rendering code. If the scorecard page looks different after the migration, the migration went wrong; if it looks identical, the migration succeeded.

One subtlety worth noting: the current scorecard page also loads `/js/voting-records.js` for the per-legislator voting record display inside expanded cards. That file contains the `ROLL_CALLS` constant, `resolveVote`, `getMemberVoteSummary`, and `classifyVote` functions. The Round 4 migration moved the data from this file into the `roll_calls` and `legislator_vote_exceptions` tables, and ported `resolveVote` into the SQL function `resolve_legislator_vote`. But the page-level helpers (`getMemberVoteSummary` and `classifyVote`) have not yet been ported to the loader. For now, the cleanest approach is to keep `voting-records.js` loaded on the page so those helpers continue to work. Once you want to display voting records for bills not in the original file, the right follow-up work is to add a `loadRollCalls()` method to the loader, retire `voting-records.js`, and re-implement the helpers in terms of the loaded data. I would treat that as a Round 4b follow-on rather than a blocker for the core migration.

## Step-by-step edits

### Edit 1: Update the script tags near the bottom of the page

Find the script-tag block around lines 866-871 of the current `/scorecard.html`. It currently reads, in this order: `scorecard-data.js`, `bill-data.js`, `voting-records.js`, `main.js`, `enhancements.js`, `site-template.js`.

Change the block to remove `scorecard-data.js` and add `ohiopride-data.js` in its place, keeping the other four tags. The loader script should come early enough that it starts fetching before the inline script runs, but the adapter function it exposes is only called once the DOM is ready, so exact ordering relative to `enhancements.js` and `site-template.js` is not critical.

The resulting block should look like this:

```html
<script src="/js/bill-data.js" defer></script>
<script src="/js/voting-records.js" defer></script>
<script src="/js/ohiopride-data.js" defer></script>
<script src="/js/main.js" defer></script>
<script src="/js/enhancements.js" defer></script>
<script src="/js/site-template.js" defer></script>
```

Note that `bill-data.js` is still referenced here even though Round 3 removed it from the issues page. That's because the scorecard page uses the `BILLS` array from that file for the "Bills Tracked" stats tile and for cross-referencing bill titles inside legislator notes. Once you've also migrated the scorecard's use of `BILLS` to the Supabase-backed loader (which is a straightforward follow-up), you can remove this line too. For Round 4 itself, leaving it in place keeps the page working with zero behavior change.

### Edit 2: Add the loader call at the top of the inline initialization block

The current inline script starts at line 874 with `document.addEventListener('DOMContentLoaded', function() {`, and immediately begins iterating over `HOUSE_MEMBERS` and `SENATE_MEMBERS` to build its `allMembers` array. The problem with the new system is that the fetch has not resolved yet at `DOMContentLoaded`, so those globals might not exist when the inline script runs.

The fix is to wait for the scorecard-loaded event before starting the rendering. Change the opening lines of the inline script from:

```javascript
document.addEventListener('DOMContentLoaded', function() {
  /* ── Combine data ── */
  var allMembers = [];
  HOUSE_MEMBERS.forEach(function(m) {
    ...
```

To:

```javascript
document.addEventListener('DOMContentLoaded', function() {
  // Kick off the Supabase fetch. Wait for the data to arrive before
  // running the rendering pipeline below.
  OhioPride.loadScorecard();

  document.addEventListener('ohp:scorecard-loaded', function() {
    /* ── Combine data ── */
    var allMembers = [];
    HOUSE_MEMBERS.forEach(function(m) {
      ...
```

And correspondingly close the extra function wrapper with a second closing brace at the bottom of the existing inline script, matching the new `ohp:scorecard-loaded` handler you just opened.

The structural shape you're creating is: the outer `DOMContentLoaded` handler calls the loader to kick off the fetch, then registers a listener for the event the loader fires when the data is ready. Everything that used to run at `DOMContentLoaded` now runs at `ohp:scorecard-loaded` instead. The timing difference is usually under a second, and the fail-open behavior of the loader means if the fetch ever fails, the page simply stays in its "loading" state rather than rendering broken content.

### Edit 3 (delete `/js/scorecard-data.js` from the repo)

Once you've verified the migration works end-to-end by loading `/scorecard` and confirming all 132 legislators render with the right scores, grades, and filter behavior, delete `/js/scorecard-data.js`. Leaving it in place does no harm (the file is no longer referenced by any page once edit 1 is applied), but deletion keeps the repository tidy and prevents future confusion.

## Verification checklist

After deploying the edits, load `/scorecard` in a browser and confirm the following.

All 132 legislators appear as cards on the page. The stats tiles at the top show the right baseline counts: total legislators, A+ champions, F hostile, and tracked bills. The grade table in the "How we score" explainer renders all six grade rows with the correct thresholds and colors. The chamber filter buttons (All, House, Senate) reduce the card count correctly when clicked. The party filter buttons (All, D, R) reduce the count correctly. The grade filter pills filter to members of the selected grade. The search box filters by name and district. Clicking a card expands it to show the component score breakdown, the notes, and any voting record rows. The "Last updated" badge at the top of the page shows a date and time close to when you last edited a legislator in Supabase.

If any of those fail, the most common culprits are: the inline script is still referring to `HOUSE_MEMBERS` directly at the top level rather than inside the `ohp:scorecard-loaded` handler (causing a reference error at page load); the loader failed to fetch because of a Supabase misconfiguration (check the Netlify function URL directly by visiting `/.netlify/functions/scorecard`, which should return JSON with 132 legislators); or the grade scale is missing from the fetch response because the Round 4 migration wasn't applied to Supabase. Each of those produces a recognizable failure mode.
