/* =============================================================================
 * Netlify Function: bills
 * -----------------------------------------------------------------------------
 * Returns the active legislative bill tracker data: every bill from
 * bills_public plus the supporting taxonomy (categories, statuses, pipeline
 * steps). This replaces the hardcoded BILLS array in /js/bill-data.js.
 *
 * The response bundles everything the /issues page needs in a single round
 * trip. We could return only the bills and have the client make separate
 * calls for categories, statuses, and pipeline steps, but those are small,
 * they rarely change, and co-locating them removes three async fetches from
 * the page-load critical path. This is a small example of a general
 * principle: denormalize at the response boundary when the data is small
 * and naturally travels together, even if the database is normalized.
 *
 * The front-end keeps the original bill-card rendering and pipeline-
 * visualization logic unchanged. It just swaps out where the data comes
 * from: instead of a hardcoded BILLS constant, it calls this endpoint and
 * hands the result to the same billCardHTML() and renderPipeline()
 * functions that already exist on the page.
 *
 * Response shape:
 *   {
 *     ok: true,
 *     bills: [
 *       {
 *         slug: "hb249",
 *         bill_number: "HB 249",
 *         title: "Indecent Exposure Modernization Act",
 *         ...
 *         status: { slug, label, short_label, color_hex, is_dead, is_law },
 *         current_step: { chamber, step_index, label, is_terminal },
 *         categories: [ { slug, label, color_hex }, ... ],
 *         pipeline_dates: { "0": "Apr 29, 2025", ... }
 *       },
 *       ...
 *     ],
 *     categories: [ { slug, label, color_hex, description }, ... ],
 *     statuses:   [ { slug, label, short_label, color_hex, is_dead, is_law }, ... ],
 *     pipeline_steps: { house: [ "Introduced", ... ], senate: [ ... ] },
 *     fetched_at: "..."
 *   }
 * ============================================================================= */

import { createClient } from '@supabase/supabase-js';

export default async (_req, _context) => {
  const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;

  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return new Response(
      JSON.stringify({ ok: false, error: 'missing_supabase_env' }),
      { status: 500, headers: { 'content-type': 'application/json' } }
    );
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
    auth: { persistSession: false },
  });

  // Parallel fetch: bills view, active categories, active statuses, pipeline
  // steps. Running them concurrently keeps the total latency close to the
  // slowest single query rather than the sum of all four.
  const [billsResult, categoriesResult, statusesResult, stepsResult] =
    await Promise.all([
      supabase
        .from('bills_public')
        .select('*')
        .order('stance', { ascending: true })          // anti first (alphabetical), then mixed, then pro
        .order('display_order', { ascending: true })
        .order('bill_number', { ascending: true }),
      supabase
        .from('bill_categories')
        .select('slug, label, color_hex, description, display_order')
        .eq('is_active', true)
        .order('display_order', { ascending: true }),
      supabase
        .from('bill_statuses')
        .select('slug, label, short_label, color_hex, is_dead, is_law, display_order')
        .eq('is_active', true)
        .order('display_order', { ascending: true }),
      supabase
        .from('bill_pipeline_steps')
        .select('chamber, step_index, label, is_terminal')
        .order('chamber', { ascending: true })
        .order('step_index', { ascending: true }),
    ]);

  // Check every result for errors before responding. Any single failure
  // should cause the whole request to fail, because returning a partial
  // payload would cause the client to render a broken page.
  for (const [name, result] of [
    ['bills', billsResult],
    ['categories', categoriesResult],
    ['statuses', statusesResult],
    ['pipeline_steps', stepsResult],
  ]) {
    if (result.error) {
      return new Response(
        JSON.stringify({ ok: false, error: `${name}_query_failed`, message: result.error.message }),
        { status: 500, headers: { 'content-type': 'application/json' } }
      );
    }
  }

  // Shape the pipeline steps into { house: [...], senate: [...] } so the
  // client can index into it by chamber without filtering.
  const pipelineSteps = { house: [], senate: [] };
  for (const s of stepsResult.data || []) {
    if (pipelineSteps[s.chamber]) {
      pipelineSteps[s.chamber][s.step_index] = s.label;
    }
  }

  // The bills view already includes category objects, status object, and
  // current_step object. We just clean up the stance ordering because the
  // Supabase client cannot enforce the "anti, mixed, pro" order we want;
  // it alphabetizes. Sort in JS to produce the site's preferred order.
  const STANCE_ORDER = { anti: 0, mixed: 1, pro: 2 };
  const bills = (billsResult.data || [])
    .slice()
    .sort((a, b) => {
      const sa = STANCE_ORDER[a.stance] ?? 99;
      const sb = STANCE_ORDER[b.stance] ?? 99;
      if (sa !== sb) return sa - sb;
      if (a.display_order !== b.display_order) return a.display_order - b.display_order;
      return String(a.bill_number).localeCompare(String(b.bill_number));
    });

  return new Response(
    JSON.stringify({
      ok: true,
      bills,
      categories:     categoriesResult.data || [],
      statuses:       statusesResult.data   || [],
      pipeline_steps: pipelineSteps,
      fetched_at:     new Date().toISOString(),
    }),
    {
      status: 200,
      headers: {
        'content-type': 'application/json',
        // Bills are updated by staff maybe a few times per week during
        // session. Edge-cache for 3 minutes, browser-cache for 1 minute,
        // serve stale for up to 30 minutes while revalidating in the
        // background. This keeps the issues page fast without creating a
        // long lag between a staff edit in Supabase and visitors seeing
        // the update.
        'cache-control': 'public, max-age=60, s-maxage=180, stale-while-revalidate=1800',
      },
    }
  );
};
