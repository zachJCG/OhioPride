/* =============================================================================
 * Netlify Function: scorecard
 * -----------------------------------------------------------------------------
 * Returns the full legislative scorecard: every active legislator with
 * their computed score, grade, component sub-scores, and notes; plus the
 * grade scale definition and pre-aggregated stats the /scorecard page
 * needs for its headline tiles.
 *
 * The design principle: ship the whole page in one response. The
 * scorecard has 132 legislators, a 6-row grade scale, and a handful of
 * aggregate counts. That bundle is small enough (a few dozen KB) that
 * there is no benefit to splitting it across multiple endpoints, and
 * shipping it together means the page hits the network exactly once,
 * saving two round-trips on the critical rendering path.
 *
 * Response shape:
 *   {
 *     ok: true,
 *     legislators: [
 *       {
 *         id, chamber, district, full_name, party,
 *         votes_score, sponsorship_score, news_score, notes,
 *         leadership_role, updated_at,
 *         score: 95,
 *         grade: { grade: "A+", label: "Champion", color_hex: "#16a34a" }
 *       },
 *       ...
 *     ],
 *     grade_scale: [ { grade, label, min_score, color_hex, description }, ... ],
 *     stats: {
 *       total: 132,
 *       by_chamber:  { house: 99, senate: 33 },
 *       by_party:    { D: ..., R: ..., I: ... },
 *       by_grade:    { "A+": ..., "A": ..., ... },
 *       by_chamber_party: {
 *         house_d: ..., house_r: ..., senate_d: ..., senate_r: ...
 *       }
 *     },
 *     updated_at: "...",   // MAX(updated_at) across all active legislators
 *     fetched_at: "..."
 *   }
 * ============================================================================= */

import { createClient } from '@supabase/supabase-js';

export default async (_req, _context) => {
  const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;

  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return new Response(
      JSON.stringify({ ok: false, error: 'missing_supabase_env' }),
      { status: 500, headers: { 'content-type': 'application/json' } }
    );
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
    auth: { persistSession: false },
  });

  // Pull the scored legislators view and the grade scale in parallel.
  // The view computes score and grade via calc_score/calc_grade so we
  // don't have to repeat that logic here.
  const [legislatorsResult, gradeScaleResult] = await Promise.all([
    supabase
      .from('legislators_scored_public')
      .select('*')
      .order('chamber',  { ascending: true })
      .order('district', { ascending: true }),
    supabase
      .from('grade_scale')
      .select('grade, label, min_score, color_hex, description, display_order')
      .eq('is_active', true)
      .order('display_order', { ascending: true }),
  ]);

  if (legislatorsResult.error) {
    return new Response(
      JSON.stringify({ ok: false, error: 'legislators_query_failed', message: legislatorsResult.error.message }),
      { status: 500, headers: { 'content-type': 'application/json' } }
    );
  }
  if (gradeScaleResult.error) {
    return new Response(
      JSON.stringify({ ok: false, error: 'grade_scale_query_failed', message: gradeScaleResult.error.message }),
      { status: 500, headers: { 'content-type': 'application/json' } }
    );
  }

  const legislators = legislatorsResult.data || [];
  const gradeScale  = gradeScaleResult.data  || [];

  // Compute the aggregate stats the /scorecard page displays in its
  // headline tiles. Doing this server-side means the client does not
  // have to loop over 132 records to count grades on every filter
  // change.
  const stats = {
    total: legislators.length,
    by_chamber:        { house: 0, senate: 0 },
    by_party:          { D: 0, R: 0, I: 0 },
    by_grade:          {},
    by_chamber_party:  { house_d: 0, house_r: 0, senate_d: 0, senate_r: 0 },
  };

  // Initialize by_grade with every possible grade from the scale, so
  // grades with zero legislators still appear in the response (makes
  // the client-side rendering predictable — no need to check for
  // undefined keys).
  for (const g of gradeScale) {
    stats.by_grade[g.grade] = 0;
  }

  // Also compute MAX(updated_at) to drive the "last updated" card on
  // the scorecard page. Same pattern as the bills endpoint.
  let maxUpdated = null;

  for (const l of legislators) {
    if (stats.by_chamber[l.chamber] !== undefined) stats.by_chamber[l.chamber] += 1;
    if (stats.by_party[l.party]     !== undefined) stats.by_party[l.party]     += 1;

    const gradeKey = l.grade?.grade;
    if (gradeKey && stats.by_grade[gradeKey] !== undefined) {
      stats.by_grade[gradeKey] += 1;
    }

    const chamberParty = `${l.chamber}_${(l.party || '').toLowerCase()}`;
    if (stats.by_chamber_party[chamberParty] !== undefined) {
      stats.by_chamber_party[chamberParty] += 1;
    }

    if (l.updated_at) {
      const ts = Date.parse(l.updated_at);
      if (!isNaN(ts) && (maxUpdated === null || ts > maxUpdated)) {
        maxUpdated = ts;
      }
    }
  }

  return new Response(
    JSON.stringify({
      ok: true,
      legislators,
      grade_scale: gradeScale,
      stats,
      updated_at: maxUpdated ? new Date(maxUpdated).toISOString() : null,
      fetched_at: new Date().toISOString(),
    }),
    {
      status: 200,
      headers: {
        'content-type': 'application/json',
        // Scorecard scores change when staff makes editorial adjustments.
        // Frequency is low — maybe a few times per week during session,
        // much less often otherwise. 3-minute edge cache with a
        // half-hour stale-while-revalidate keeps the page fast without
        // making edits feel laggy.
        'cache-control': 'public, max-age=60, s-maxage=180, stale-while-revalidate=1800',
      },
    }
  );
};
