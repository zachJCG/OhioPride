# Ohio Pride PAC — Supabase Migration Deployment Guide

## What this deployment does, and why

This deployment moves the dynamic content on ohiopride.org out of hardcoded HTML and JavaScript arrays and into a Supabase Postgres database. The goal is operational, not technical. Today, every time someone is added to the board, every time a founding-member tier price changes, every time an officer turns over, every time a bill moves through committee, someone has to edit an HTML or JavaScript file and push a deploy. After this migration, those changes become database row edits, which means they can be made by a non-developer through the Supabase dashboard and they propagate to every page on the site automatically.

The migration happens in three rounds, and the rounds matter. Round 1 moves the two pieces of content that are operationally most painful right now: the board grid on `/board` and the founding-member progress bar on `/founding-members`. Round 2 moves three configuration tables that share the same architectural pattern as Round 1 but a different operational rhythm: the founding-member tier ladder, the corporate sponsorship tier ladder for the forthcoming Ohio Pride Action c(4) entity, and the site-wide officer leadership block used in the compliance disclaimer. Round 3 moves the legislative bill tracker, which is a larger and more relationally complex dataset than anything in Rounds 1 and 2 — twenty-two bills across eight categories and two chambers, each with its own pipeline progress and status history.

Doing this work in three rounds rather than one serves two purposes. The obvious one is risk reduction: you can deploy each round, verify it works in production, and then come back for the next. The less obvious one is conceptual: each round introduces a new architectural idea that builds on the previous one. Round 1 teaches the pattern of a table plus a public view plus a Netlify function plus a client-side loader. Round 2 teaches the pattern of configuration tables that feed multiple pages from a single source. Round 3 teaches the pattern of relational data with foreign keys, join tables, and denormalized summary columns. If you come back to add a new type of content later — endorsements, events, scorecard entries — one of these three patterns will be the right fit, and you will already understand why.

The three rounds can be deployed together as one operation, or separated by any amount of time. Round 2 depends on Round 1 having run, because Round 2's migration references the `set_updated_at()` trigger function that Round 1 creates. Round 3 depends on Round 1 for the same reason. But there is no other cross-coupling: the Round 1 functions continue to work unchanged after Round 2 runs, Round 2 continues to work unchanged after Round 3 runs, and rolling back any single round does not affect the others.

## What is in this drop

The drop contains thirteen files organized into the three directory structures that mirror where they need to live in your repository. The `supabase/migrations/` directory contains four SQL migration files that need to be run in filename order against your Supabase project. The `netlify/functions/` directory contains seven JavaScript Netlify functions: one scheduled (the hourly ActBlue sync) and six on-demand HTTP endpoints that the website calls when pages load. The `public/js/` directory contains two client-side JavaScript files that replace existing hardcoded behaviors on the website.

There is one additional thing to know about the file layout. Two of the client-side files, `ohiopride-data.js` and `site-template.js`, are replacement versions of files already on your site today. The new `site-template.js` adds data-attributes to the disclaimer and directors block so the leadership loader can find and populate them, but leaves the existing hardcoded values in place as fallbacks. The new `ohiopride-data.js` is a consolidated version that includes all the loader methods from Rounds 1, 2, and 3 in one file. Both are safe to swap in wholesale.

## Dependencies that need to be installed once

Before any of the Netlify functions will work, your repository needs the Supabase JavaScript client. From the root of your site repo, run `npm install @supabase/supabase-js`. This adds one line to your `package.json` and pulls down the dependency. Netlify will install it automatically on every build once it is listed as a dependency. If you already have this installed from an earlier deployment, the command is safe to re-run — npm will do nothing if the package is already at the requested version.

## Deployment steps, in order

### Step 1: Run the migrations against Supabase

The four migration files in `supabase/migrations/` need to be applied to your Supabase project in filename order. The filename timestamps sort them correctly: `20260421000000_initial_schema.sql` runs first, then `20260422000000_configuration_tables.sql`, then `20260423000000_bill_tracker.sql`, then `20260423000001_bill_tracker_seed_additional.sql`.

The simplest way to run them is through the Supabase dashboard: open the SQL editor, paste the contents of each file, click Run, wait for the success message, then move on to the next. All four files are idempotent — they use `create table if not exists`, `create index if not exists`, and `on conflict do nothing` throughout — so if anything fails partway and you need to re-run, nothing breaks and nothing duplicates. If you are using the Supabase CLI or MCP, the files follow the standard timestamp-prefix naming convention and can be applied with `supabase db push`.

After all four migrations finish, verify in the Supabase dashboard that the following objects exist. You should see ten tables in the `public` schema. Rounds 1 and 2 contribute `board_members`, `founding_members`, `founding_member_tiers`, `sponsorship_tiers`, and `site_leadership`. Round 3 adds `bills`, `bill_categories`, `bill_statuses`, `bill_pipeline_steps`, and `bill_category_assignments`. You should also see two views: `founding_members_public` from Round 1 and `bills_public` from Round 3. Row Level Security should be enabled on every table. The bill-related tables should be seeded with twenty-two bill records, eight categories, eleven statuses, and eighteen pipeline steps (nine per chamber).

### Step 2: Set environment variables on Netlify

The Netlify functions read configuration from environment variables, which you set in the Netlify dashboard under Site settings, then Environment variables. Do not put any of these in git. Two of them — the Supabase service role key and the ActBlue password — grant full write access to the database and full read access to every contribution that has ever come through your ActBlue, respectively. Keeping them out of git keeps them out of the hands of anyone who can clone the repository.

You need to set six variables. `SUPABASE_URL` is the HTTPS URL of your Supabase project, which you can find under Settings, then API, in the Supabase dashboard. It looks like `https://abcdefgh.supabase.co`. `SUPABASE_SERVICE_ROLE_KEY` is also under Settings, then API; it is specifically the key labeled "service_role secret", not the anon key. `ACTBLUE_USERNAME` and `ACTBLUE_PASSWORD` come from the ActBlue administrative interface under Integrations, then Contribution Data Service; these are API credentials, not your ActBlue login. `ACTBLUE_FORM_SLUG` should be set to `ohio-pride-pac`, matching the slug in your actual ActBlue donation URLs. And `ACTBLUE_FOUNDING_REFCODE_PREFIX` should be set to `founding_`, which is the convention the sync function uses to distinguish founding-member contributions from other donations on the same ActBlue form.

### Step 3: Commit the files to your repository

Drop the thirteen files into their matching paths in the `ohiopride-web` repository, then commit and push to `main`. Netlify auto-deploys on every push to `main`, so this single commit triggers the deploy. The build should succeed on the first try because the Netlify functions are self-contained and the migrations have already been applied to Supabase.

One thing to watch for during this first deploy: if you had a previous version of `site-template.js` or `ohiopride-data.js` in the repository, Git will show those files as modified, not added. That is correct and expected. The new versions are specifically consolidated replacements of what you have deployed today.

### Step 4: Add the ActBlue sync cron to netlify.toml

The hourly ActBlue sync is a scheduled function, which in Netlify terminology means it runs on a cron rather than in response to HTTP requests. You register the schedule in `netlify.toml` at the root of your repository. If you do not already have a `netlify.toml`, create one; if you have one, add the block below without removing anything that is already there.

```toml
[[scheduled.functions]]
  path = "/.netlify/functions/actblue-sync"
  schedule = "@hourly"
```

Netlify re-reads `netlify.toml` on every deploy, so the schedule becomes active after your next push.

### Step 5: Swap the hardcoded client code on the three affected pages

This is the only step that requires hand-editing HTML files in your repository. The edits are small and they all gain the same pattern: remove the hardcoded data block, add a script tag pointing to `ohiopride-data.js`, and add a small inline script that calls the right loader on DOMContentLoaded.

For `/founding-members.html`, there are four separate pieces of content to replace. The tier-legend cards near line 222 that currently hardcode five `<div class="tier-legend-card">` blocks should be emptied out — keep the wrapping `<div class="tier-grid reveal-stagger" id="tierGrid">` container, adding the `id="tierGrid"` attribute if it is not already there, but remove all its children. The tier-group member list near line 251, which currently hardcodes Nicole Green, Zachary Smith, and Jesse Shepherd into `<div class="tier-group">` blocks, should also be emptied, keeping only the wrapping `<div class="member-list reveal" id="memberList">` container with the new `id` added. The inline `<script>` at the bottom of the page that sets `FOUNDING_MEMBER_COUNT = 3` should be deleted entirely. And at the bottom of the page, just before the closing `</body>` tag, add:

```html
<script src="/js/ohiopride-data.js" defer></script>
<script defer>
  document.addEventListener('DOMContentLoaded', function () {
    OhioPride.loadProgress('#goalFill', '#progressText');
    OhioPride.loadFoundingMemberTiers('#tierGrid');
    OhioPride.loadPublicMembers('#memberList');
  });
</script>
```

For `/board.html`, the edit is simpler because the whole file currently runs as one big inline script. Find the block that starts `var boardMembers = [` near line 470 and ends `grid.appendChild(card)` near line 650, and delete that entire block. In its place, add:

```html
<script src="/js/ohiopride-data.js" defer></script>
<script defer>
  document.addEventListener('DOMContentLoaded', function () {
    OhioPride.loadBoard('#boardGrid');
  });
</script>
```

The `<div id="boardGrid">` container, all the CSS for `.board-card`, the name-strip marquee logic, and the intersection-observer scroll animations all stay unchanged.

For `/issues.html`, the edit is more involved because the page has three interacting scripts. Today the page loads `/js/main.js`, `/js/bill-data.js`, `/js/bill-pipeline.js`, and `/js/enhancements.js` as separate files, and the inline script at the bottom of the page defines `billCardHTML()` and `renderBills()` and then calls `renderBills(BILLS)` to render the hardcoded array. After the migration, you keep every rendering function exactly as it is and just change where the data comes from.

Remove the `<script src="/js/bill-data.js"></script>` tag near line 775 entirely — the file still exists on disk as a reference, but the page no longer needs to load it because the data now comes from the Netlify function. Keep the three other script tags in place (`main.js`, `bill-pipeline.js`, `enhancements.js`). Add a new script tag for the data loader alongside the others:

```html
<script src="/js/ohiopride-data.js" defer></script>
```

Then in the inline script at the bottom of the page, find the line that currently reads `renderBills(BILLS)` and replace it with `OhioPride.loadBills('#billsContainer')`. Everything else in the inline script — the `billCardHTML()` function, the `renderBills()` function, the stance grouping, the category color lookup, the filter-button wiring — stays exactly as it was. The loader calls your `renderBills()` function for you, passing in the fresh data from Supabase.

For every page that uses the shared site-template footer, which is nearly every page today, no edits are needed. The updated `site-template.js` handles the leadership loading automatically as long as `ohiopride-data.js` is loaded on the page. If you want to be certain the footer disclaimer updates on pages that do not already load `ohiopride-data.js`, add the following line to every page's `<head>` alongside the existing `site-template.js` tag:

```html
<script src="/js/ohiopride-data.js" defer></script>
```

### Step 6: Smoke test each endpoint

Before you consider the migration done, hit each of the seven Netlify function URLs directly in a browser and verify the JSON response looks correct. The Round 1 endpoints return: `/.netlify/functions/founding-members-progress` with a JSON object containing `member_count: 3`, `goal: 1969`, and a small non-zero `total_cents` reflecting the seeded members; `/.netlify/functions/board-members` with ten members in an array. The Round 2 endpoints return: `/.netlify/functions/founding-member-tiers` with five tiers; `/.netlify/functions/public-members` with three members grouped into tiers; `/.netlify/functions/site-leadership` with the Director and Treasurer and a pre-assembled disclaimer string. The Round 3 endpoint `/.netlify/functions/bills` returns an object with a `bills` array of twenty-two items, a `categories` array of eight items, a `statuses` array of eleven items, and a `pipeline_steps` object with `house` and `senate` arrays of nine strings each.

The `/.netlify/functions/actblue-sync` endpoint can be triggered manually from the Netlify Functions UI; it should return `rows_written: 0` until real ActBlue contributions start arriving, because the seeded rows have synthetic contribution IDs that no live ActBlue CSV will contain.

Then load `/board`, `/founding-members`, and `/issues` in a browser and make sure they render identically to how they did before the migration. If anything is missing or broken, check the browser's developer console for network errors on the function URLs — that will tell you whether the issue is on the Netlify side or the client side.

## A closer look at the Round 3 architecture

Round 3 introduces two design patterns that are worth understanding because they are likely to show up again in future rounds of migrations. The first is the use of a join table to express a many-to-many relationship between bills and categories. In the original JavaScript data, each bill had `categories: ["expression", "anti-trans"]` as an array. That works fine as an in-memory data structure, but it creates a problem in a relational database: the list of valid categories and their display colors has to be duplicated on every bill record, and if you rename a category you have to hunt down every bill that uses the old name. The join-table pattern separates these concerns cleanly. Categories live in `bill_categories` with their slug, label, and color. Each bill-to-category tag lives as a single row in `bill_category_assignments` with just the two foreign keys. Adding a tag to a bill is an insert into the join table; removing a tag is a delete; renaming a category is a single row update in `bill_categories` that every assigned bill picks up automatically.

The second pattern is the denormalized summary column. The `pipeline_dates` column on the bills table stores a JSON object that maps step indices to date strings. You could imagine normalizing this into a `bill_actions` table where each row represents "bill X reached step Y on date Z", which would be the textbook correct design. I chose not to do that yet for two specific reasons. The first is that we do not have the historical data to populate such a table; going back and reconstructing when every bill hit every step would mean scraping the Ohio Legislature site for every action log. The second is that the current website only uses these dates to render the pipeline visualization, never to query across bills or aggregate by date. So the denormalized summary is the simpler design that adequately serves the current use case, with the understanding that if we ever need true action-level queries, adding a `bill_actions` table is an additive change that does not break anything existing.

The tradeoff to be aware of is that if you ever manually update the `current_step_index` on a bill, you are responsible for also updating the `pipeline_dates` JSON to record the date of that step. A future improvement would be to add a trigger that automatically appends to `pipeline_dates` whenever `current_step_index` changes, so the two stay in sync without requiring the person doing the update to remember.

## What the migration deliberately does not do yet

A few things are intentionally left for later rounds, either because they are not operationally urgent or because they require design decisions that have not been made yet.

The sponsorship tier page is not wired up on the PAC site. The table is seeded with the seven-tier Onyx-through-Diamond program, but the rows are tagged `entity='c4'` and will never appear on an Ohio Pride PAC surface. When the Ohio Pride Action c(4) website comes online, adding a sponsorship page there is a matter of creating a new Netlify function that queries `sponsorship_tiers` with the entity filter, and a new client-side loader that mirrors `loadFoundingMemberTiers()`.

The bill tracker does not yet have individual bill detail pages wired up to Supabase. The current site generates pages like `/issues/hb249` from static HTML files, each of which duplicates information that is now in the database. A future round could introduce a single dynamic template that renders any bill by slug, reading from `bills_public`, which would eliminate the need to hand-edit a detail file every time a bill's status changes.

The ActBlue sync does not yet populate a dedicated `recurrence` column on contributions. Right now the tier classifier falls back to treating all contributions as one-time when the ActBlue CSV recurrence fields are empty. Once you see real data flowing through ActBlue and can confirm which specific column name your ActBlue account uses for recurrence, a three-line change to the sync function will fix that.

Endorsements, scorecard entries, event listings, and press mentions are all natural future additions using the same patterns established here. Each would follow either the Round 1 shape (single table plus view plus function plus loader), the Round 2 shape (single table driving multiple pages), or the Round 3 shape (relational data with foreign keys and join tables), depending on what fits the content best.

## What to do if something goes wrong

Every piece of this migration is designed to fail open. If the Netlify function is down, the website shows whatever hardcoded fallback content is in the HTML. If the Supabase database is down, the Netlify functions return 500 and the client-side loaders silently keep the fallback visible. If the ActBlue sync fails, the next hourly run tries again with a 48-hour lookback window, so one failed run does not cost you any data. The only thing that would cause a visible problem on the website is a bug in one of the client-side loaders that removes content before the fetch completes and then cannot recover. The loaders are written to render new content only on successful fetch, so that failure mode should not happen, but if it does, rolling back means restoring the previous `ohiopride-data.js`, `site-template.js`, and the three modified HTML files — no database changes are needed to revert.
