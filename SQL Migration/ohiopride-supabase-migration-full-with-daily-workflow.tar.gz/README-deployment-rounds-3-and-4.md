# Ohio Pride PAC — Supabase Migration Deployment Guide, Rounds 3 and 4

This document extends the Round 1-2 deployment guide with the steps needed to deploy the bill tracker migration (Round 3) and the legislative scorecard migration (Round 4). You should have the Round 1-2 README open in another tab when you work through this one, because the two build on each other and several steps below reference setup that was done in the earlier deployment. If you have not yet deployed Rounds 1 and 2, you can still deploy Rounds 3 and 4 in the same session: just run all the migrations in order, set all the environment variables at once, and commit the full set of files in a single push.

## What Rounds 3 and 4 do, and why they are paired

Round 3 moves the bill tracker out of hardcoded JavaScript arrays and into a proper relational schema with a bills table, a supporting taxonomy of categories and pipeline steps, and a join table for the many-to-many relationship between bills and categories. Round 4 moves the legislative scorecard out of hardcoded JavaScript arrays into a schema with 132 legislators, a grade scale, and supporting tables for roll-call votes and vote exceptions. The two rounds share a design philosophy and part of their mental model: the scorecard cross-references bill slugs from the bill tracker when it documents which bills a legislator co-sponsored or voted on, so having the bill tracker migrated first means the scorecard migration can reference real database data rather than hardcoded strings.

These two rounds are also the largest migrations we have done so far in terms of row counts. Round 3 adds 22 bill records, 8 categories, 11 statuses, and 18 pipeline steps, for a total of roughly 60 new rows plus a handful of join-table entries. Round 4 adds 132 legislator records plus 6 grade thresholds, 2 roll calls, and 1 vote exception. Together they roughly triple the data in your Supabase instance, which is still a very small database by any meaningful standard but is worth mentioning because it means the seed files take a few seconds to run rather than a fraction of a second.

## Deployment steps, in order

### Step 1: Run the new migrations against Supabase

The migrations must run in filename order because Round 4 depends on the `set_updated_at()` trigger function created in Round 1 and does not reference any Round 3 objects directly but does conceptually follow on from Round 3 in the overall progression. Run these five files in the Supabase SQL editor, in order, waiting for each to complete successfully before starting the next. Each file is idempotent — re-running any of them is safe and produces no duplicates.

The first file is `20260423000000_bill_tracker.sql`, which creates the bills, categories, statuses, pipeline steps, and bill-category join tables, seeds the reference taxonomy, and inserts HB 249 as a worked example. The second is `20260423000001_bill_tracker_seed_additional.sql`, which inserts the remaining 21 bills using the `seed_bill()` helper function defined in the first file. The third is `20260423000002_bill_tracker_view_updated_at.sql`, which adds the `updated_at` field to the `bills_public` view so the "Last Updated" card on the issues page can display a meaningful timestamp. The fourth is `20260424000000_scorecard.sql`, which creates the scorecard schema with all five tables, the three helper functions, the public view, and all the RLS policies. The fifth is `20260424000001_scorecard_seed_legislators.sql`, which inserts all 132 legislators. The sixth and final is `20260424000002_scorecard_seed_rollcalls.sql`, which inserts the 2 roll calls and 1 vote exception from the current `voting-records.js`.

After all six files have run, verify in the Supabase dashboard that the new objects exist. You should see five new tables: `bills`, `bill_categories`, `bill_statuses`, `bill_pipeline_steps`, and `bill_category_assignments` from Round 3; and four more tables from Round 4: `grade_scale`, `legislators`, `roll_calls`, and `legislator_vote_exceptions`. You should see the `bills_public` view and the `legislators_scored_public` view. The `bills` table should have 22 rows, `bill_categories` 8, `bill_statuses` 11, and `bill_pipeline_steps` 18. The `legislators` table should have 132 rows, with 99 having `chamber = 'house'` and 33 having `chamber = 'senate'`. If any of those counts are off, the seed files did not complete cleanly; look for foreign-key or check-constraint errors in the Supabase logs.

### Step 2: Environment variables (no changes)

The three Netlify functions added in these rounds (`bills`, `scorecard`) read from the same `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` environment variables you already configured in Round 1. No new variables are needed. If you are deploying all four rounds at once, set the variables as documented in the Round 1-2 README and you are done with this step.

### Step 3: Commit and push the new code

The code drop contains three new Netlify functions (`bills.mjs` and `scorecard.mjs`) plus an updated `ohiopride-data.js` that now exposes two additional methods (`loadBills` and `loadScorecard`) alongside the Round 1-2 methods. Commit and push all three files in the same push. Netlify auto-deploys and the new functions become available immediately at their respective URLs.

### Step 4: Perform the HTML swaps on the two affected pages

The bill tracker migration requires edits to `/issues.html`, and the scorecard migration requires edits to `/scorecard.html`. The precise instructions are in two separate documents, `ROUND3-html-swap-instructions.md` and `ROUND4-html-swap-instructions.md`, and I recommend reading the specific one before doing each edit. The edits are small — each page gains one script tag reference, each page gains one loader invocation, and each page loses one hardcoded data reference — but the specific lines involved are precise enough that a general description is not as useful as the per-page walkthrough.

The key design property worth understanding before you make these edits is that both pages keep their existing rendering code exactly as it is. Only the data source changes. This means the visual output should be identical before and after the migration, which makes verification straightforward: load the page, confirm the same bills or legislators appear in the same order with the same formatting, and you know the migration succeeded.

### Step 5: Smoke-test each endpoint

After the deploy finishes, hit each new function URL directly in a browser and verify the JSON looks correct. The bills endpoint at `/.netlify/functions/bills` should return 22 bills with their statuses, categories, and pipeline steps as nested objects, plus a `categories` array and a `statuses` array at the top level. The scorecard endpoint at `/.netlify/functions/scorecard` should return 132 legislators, each with a computed `score` integer between 0 and 100, a `grade` object with letter grade and color, and a `stats` section at the top level showing aggregate counts by chamber, party, and grade.

Then load `/issues` and `/scorecard` in a browser and make sure they render identically to how they did before. The verification checklists in the two HTML swap documents cover the specific things to check on each page.

## What these rounds deliberately do not do

A few things are left for follow-on work. The cross-reference between the scorecard and the bill tracker is still done by pattern-matching bill numbers in legislator notes (the `parseBills()` function in the scorecard page), rather than by a proper join between legislator records and the bills they sponsored or voted on. Building a first-class `legislator_bill_sponsorships` table to formalize that relationship would be a reasonable follow-up migration and would let you produce queries like "every bill that any A+ legislator co-sponsored" without string matching. But the current approach works fine for display purposes and there is no rush.

The voting-records data is still loaded from `/js/voting-records.js` on the scorecard page because the `getMemberVoteSummary` and `classifyVote` helper functions used by the per-legislator card expansion are not yet in the loader. The underlying data is now in Supabase (the Round 4 migration seeded the 2 roll calls and 1 exception), but the client-side glue to read it from there is a loose end. Adding a `loadRollCalls()` method to the loader and porting those two helper functions into the loader is the natural next step, and would let you delete `voting-records.js` entirely.

Both follow-ons are small and additive. Neither is a blocker for shipping Rounds 3 and 4 as-is.
