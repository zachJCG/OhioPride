-- =============================================================================
-- Ohio Pride PAC - Migration 4 (companion 2): Roll Calls + Vote Exceptions
-- -----------------------------------------------------------------------------
-- Run after 20260424000000_scorecard.sql AND
-- 20260424000001_scorecard_seed_legislators.sql (exception inserts
-- need to look up legislator IDs by chamber + district, which
-- requires legislators to already exist).
--
-- Generated from voting-records.js at 2026-04-22T01:48:48.135Z.
-- =============================================================================

-- Roll call: hb249-h-pass (House Passage, 2026-03-25)
insert into public.roll_calls
  (bill_slug, bill_label, chamber, stage, label, vote_date, result, stance)
values
  ('hb249', 'HB 249', 'house', 'pass', 'House Passage', '2026-03-25', 'Passed 63–32', 'anti')
on conflict (bill_slug, chamber, stage, general_assembly) do nothing;

-- Exception: H57 voted N on hb249-h-pass
insert into public.legislator_vote_exceptions (roll_call_id, legislator_id, vote)
select rc.id, l.id, 'N'
from public.roll_calls rc, public.legislators l
where rc.bill_slug = 'hb249' and rc.chamber = 'house' and rc.stage = 'pass'
  and l.chamber = 'house' and l.district = 57 and l.is_active = true
on conflict (roll_call_id, legislator_id) do nothing;

-- Roll call: sb34-s-pass (Senate Passage, 2025-11-20)
insert into public.roll_calls
  (bill_slug, bill_label, chamber, stage, label, vote_date, result, stance)
values
  ('sb34', 'SB 34', 'senate', 'pass', 'Senate Passage', '2025-11-20', 'Passed 23–10', 'anti')
on conflict (bill_slug, chamber, stage, general_assembly) do nothing;

-- SEATED_SINCE was empty in voting-records.js; no overrides to apply.