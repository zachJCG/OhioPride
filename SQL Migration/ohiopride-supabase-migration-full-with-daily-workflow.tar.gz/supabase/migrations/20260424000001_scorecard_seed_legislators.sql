-- =============================================================================
-- Ohio Pride PAC - Migration 4 (companion): 132 Legislators
-- -----------------------------------------------------------------------------
-- Run this file after 20260424000000_scorecard.sql. Uses the
-- public.seed_legislator() function defined in that migration.
--
-- Generated from scorecard-data.js at 2026-04-22T01:48:01.027Z.
-- Idempotent: re-running safely updates existing rows because
-- seed_legislator uses ON CONFLICT DO UPDATE on (chamber, district, is_active).
-- =============================================================================

-- ---- HOUSE MEMBERS (99 seats) ----

select public.seed_legislator('house', 1, 'Dontavius L. Jarrells', 'D', 5, 3, 2, 'Primary sponsor HB 306 (Hate Crimes Act). Votes consistently against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 2, 'Latyna M. Humphrey', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 3, 'Ismail Mohamed', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 4, 'Beryl Brown Piccolantonio', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 5, 'Meredith R. Lawson-Rowe', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 6, 'Christine Cockley', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 7, 'C. Allison Russo', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills. House Minority Leader.');
select public.seed_legislator('house', 8, 'Anita Somani', 'D', 5, 0, 1, 'Votes against anti-LGBTQ+ bills. Medical professional; vocal on healthcare bills.');
select public.seed_legislator('house', 9, 'Munira Abdullahi', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 10, 'Mark Sigrist', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 11, 'Crystal Lett', 'D', 5, 5, 2, 'Primary sponsor HB 136 (Fairness Act), co-sponsor HB 300 (conversion therapy ban). Champion.');
select public.seed_legislator('house', 12, 'Brian Stewart', 'R', -5, -3, -1, 'Primary sponsor Sub HB 96 (budget with anti-LGBTQ+ provisions). Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 13, 'Tristan Rader', 'D', 5, 5, 3, 'Primary sponsor HB 136 (Fairness Act). Vocal advocate for LGBTQ+ rights. Hosts Pride press conferences.');
select public.seed_legislator('house', 14, 'Sean P. Brennan', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 15, 'Chris Glassburn', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 16, 'Bride Rose Sweeney', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 17, 'Michael D. Dovilla', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 18, 'Juanita O. Brent', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 19, 'Phillip M. Robinson, Jr.', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 20, 'Terrence Upchurch', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 21, 'Eric Synenberg', 'D', 5, 0, 1, 'Votes against anti-LGBTQ+ bills. Participated in Pride press conference.');
select public.seed_legislator('house', 22, 'Darnell T. Brewer', 'D', 5, 2, 1, 'Co-sponsor HB 327 (PRIDE Act). Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 23, 'Daniel P. Troy', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 24, 'Dani Isaacsohn', 'D', 5, 0, 1, 'Votes against anti-LGBTQ+ bills. Vocal opponent of HB 68 in 135th GA.');
select public.seed_legislator('house', 25, 'Cecil Thomas', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 26, 'Ashley Bryant Bailey', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 27, 'Rachel B. Baker', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 28, 'Karen Brownlee', 'D', 5, 5, 2, 'Primary sponsor HB 300 (conversion therapy ban), HB 327 (PRIDE Act). Strong champion.');
select public.seed_legislator('house', 29, 'Cindy Abrams', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 30, 'Mike Odioso', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 31, 'Bill Roemer', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 32, 'Jack K. Daniels', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 33, 'Veronica R. Sims', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 34, 'Derrick Hall', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 35, 'Steve Demetriou', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 36, 'Andrea White', 'R', -2, 0, 1, 'Voted against HB 8 (forced outing). Otherwise votes party line on anti-LGBTQ+ bills.');
select public.seed_legislator('house', 37, 'Tom Young', 'R', -5, -2, -1, 'Co-sponsor HB 6 (companion to SB 1 DEI ban). Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 38, 'Desiree Tims', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 39, 'Phil Plummer', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 40, 'Rodney Creech', 'R', -5, -3, -3, 'Primary sponsor HB 196 (trans candidate disclosure). Accused of sexual misconduct with minor relative (BCI documents).');
select public.seed_legislator('house', 41, 'Erika White', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 42, 'Elgin Rogers, Jr.', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 43, 'Michele Grim', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 44, 'Josh Williams', 'R', -5, -15, -3, 'Primary/co-sponsor of 8+ anti-LGBTQ+ bills: HB 249, 155, 190, 262, 693, 796, 798. Most prolific anti-LGBTQ+ bill author in 136th GA.');
select public.seed_legislator('house', 45, 'Jennifer Gross', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 46, 'Thomas Hall', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 47, 'Diane Mullins', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 48, 'Scott Oelslager', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 49, 'Jim Thomas', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 50, 'Matthew Kishman', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 51, 'Jodi Salvo', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 52, 'Gayle Manning', 'R', -2, 0, 1, 'Voted against HB 8 (forced outing) and original HB 6 (sports ban) in committee. Otherwise party line.');
select public.seed_legislator('house', 53, 'Joseph A. Miller, III', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 54, 'Kellie Deeter', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 55, 'Michelle Teska', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 56, 'Adam Mathews', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 57, 'Jamie Callender', 'R', 5, 0, 3, 'Only Republican to vote against HB 68, HB 6, HB 8, and HB 249. Stated: ''I am a Republican because I believe in empowering individuals and limiting government.''');
select public.seed_legislator('house', 58, 'Lauren McNally', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('house', 59, 'Tex Fischer', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 60, 'Brian Lorenz', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 61, 'Beth Lear', 'R', -5, -6, -2, 'Primary sponsor HB 155 (DEI ban), HB 262 (Natural Family Month). Anti-equality rhetoric.');
select public.seed_legislator('house', 62, 'Jean Schmidt', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 63, 'Adam C. Bird', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 64, 'Nick Santucci', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 65, 'David Thomas', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 66, 'Sharon A. Ray', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 67, 'Melanie Miller', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 68, 'Thaddeus J. Claggett', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 69, 'Kevin D. Miller', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 70, 'Brian Lampton', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 71, 'Levi Dean', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 72, 'Heidi Workman', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 73, 'Jeff LaRe', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 74, 'Bernard Willis', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 75, 'Haraz N. Ghanbari', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 76, 'Marilyn John', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 77, 'Meredith Craig', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 78, 'Matt Huffman', 'R', -5, 0, -1, 'Votes for anti-LGBTQ+ bills. Former Senate President who advanced anti-LGBTQ+ agenda.');
select public.seed_legislator('house', 79, 'Monica Robb Blasdel', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 80, 'Johnathan Newman', 'R', -5, -6, -2, 'Primary sponsor HB 190 (Given Names Act), HB 172 (mental health consent removal). Ties to Center for Christian Virtue (SPLC-designated anti-LGBTQ group).');
select public.seed_legislator('house', 81, 'James M. Hoops', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 82, 'Roy Klopfenstein', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 83, 'Ty D. Mathews', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 84, 'Angela N. King', 'R', -5, -6, -2, 'Primary sponsor HB 249 (drag ban), co-sponsor HB 196 (trans candidate disclosure). Vocal proponent of anti-LGBTQ+ legislation.');
select public.seed_legislator('house', 85, 'Tim Barhorst', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 86, 'Tracy M. Richardson', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 87, 'Riordan T. McClain', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 88, 'Gary Click', 'R', -5, -6, -3, 'Primary sponsor HB 68 (135th GA, care ban) and HB 693 (affirming families). Compared trans people to ''Lucifer.'' Misconduct-related allegations involving minors.');
select public.seed_legislator('house', 89, 'D. J. Swearingen', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 90, 'Justin Pizzulli', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 91, 'Bob Peterson', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 92, 'Mark Johnson', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 93, 'Jason Stephens', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 94, 'Kevin Ritter', 'R', -5, -3, -1, 'Primary sponsor HB 507 (School Chaplain Act). Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 95, 'Ty Moore', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 96, 'Ron Ferguson', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 97, 'Adam Holmes', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 98, 'Mark Hiner', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('house', 99, 'Sarah Fowler Arthur', 'R', -5, 0, -1, 'Votes for anti-LGBTQ+ bills. Known for far-right positions.');

-- ---- SENATE MEMBERS (33 seats) ----

select public.seed_legislator('senate', 1, 'Rob McColley', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 2, 'Theresa Gavarone', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 3, 'Michele Reynolds', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 4, 'George F. Lang', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 5, 'Stephen A. Huffman', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 6, 'Willis E. Blackshear, Jr.', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 7, 'Steve Wilson', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 8, 'Louis W. Blessing, III', 'R', -3, 0, 1, 'Voted against HB 8 (forced outing) in Senate. Otherwise votes party line.');
select public.seed_legislator('senate', 9, 'Catherine D. Ingram', 'D', 5, 0, 1, 'Votes against anti-LGBTQ+ bills. Vocal opponent of SB 104 (bathroom ban).');
select public.seed_legislator('senate', 10, 'Kyle Koehler', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 11, 'Paula Hicks-Hudson', 'D', 5, 0, 1, 'Votes against anti-LGBTQ+ bills. Argued ''Just let me live'' during HB 68 override debate.');
select public.seed_legislator('senate', 12, 'Susan Manchester', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 13, 'Nathan H. Manning', 'R', -1, 0, 2, 'Only Republican senator to vote against HB 68 veto override. Notable crossover on major bill.');
select public.seed_legislator('senate', 14, 'Terry Johnson', 'R', -5, -3, -1, 'Primary sponsor SB 34 (Ten Commandments in schools).');
select public.seed_legislator('senate', 15, 'Hearcel F. Craig', 'D', 5, 0, 0, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 16, 'Beth Liston', 'D', 5, 2, 1, 'Co-sponsor SB 71 (conversion therapy ban). Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 17, 'Shane Wilkin', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 18, 'Jerry C. Cirino', 'R', -5, -9, -3, 'Primary sponsor SB 1 (DEI ban), co-sponsor SB 104 (bathroom ban), SB 274 (minor consent). Religious arguments for HB 68 override.');
select public.seed_legislator('senate', 19, 'Andrew O. Brenner', 'R', -5, -9, -2, 'Primary sponsor SB 113 (school DEI ban), SB 274 (minor consent), co-sponsor SB 104 (bathroom ban). Called DEI ''institutional discrimination.''');
select public.seed_legislator('senate', 20, 'Tim Schaffer', 'R', -5, -3, 0, 'Primary sponsor SB 53 (anti-protest/vandalism).');
select public.seed_legislator('senate', 21, 'Kent Smith', 'D', 5, 0, 1, 'Criticized ''state-sponsored bullying of trans youth'' during HB 68 debate.');
select public.seed_legislator('senate', 22, 'Mark Romanchuk', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 23, 'Nickie J. Antonio', 'D', 5, 9, 3, 'Primary sponsor SB 70 (Fairness Act, 12th time), SB 71 (conversion therapy ban), SB 211 (Love Makes a Family). Senate Minority Leader. First openly LGBTQ+ Ohio legislator.');
select public.seed_legislator('senate', 24, 'Thomas F. Patton', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 25, 'William P. DeMora', 'D', 5, 0, 1, 'Motioned to adjourn before HB 68 override vote.');
select public.seed_legislator('senate', 26, 'Bill Reineke', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 27, 'Kristina D. Roegner', 'R', -5, 0, -2, 'Made anti-trans statements during HB 68 override debate.');
select public.seed_legislator('senate', 28, 'Casey Weinstein', 'D', 5, 0, 1, 'Votes against anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 29, 'Jane M. Timken', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 30, 'Brian M. Chavez', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 31, 'Al Landis', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 32, 'Sandra O''Brien', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');
select public.seed_legislator('senate', 33, 'Al Cutrona', 'R', -5, 0, 0, 'Votes for anti-LGBTQ+ bills.');