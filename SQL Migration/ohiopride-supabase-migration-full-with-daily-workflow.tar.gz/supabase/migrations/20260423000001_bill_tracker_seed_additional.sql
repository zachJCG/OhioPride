-- =============================================================================
-- Ohio Pride PAC - Migration 3 (companion): Remaining 21 Bills
-- -----------------------------------------------------------------------------
-- Run this file after 20260423000000_bill_tracker.sql. It uses the
-- public.seed_bill() function defined in that migration.
--
-- Generated from bill-data.js at 2026-04-22T01:40:00.741Z.
-- Category slugs from bill-data.js are translated to their
-- canonical forms (education -> education-dei, elections ->
-- elections-privacy, youth -> youth-family) to match the seed in
-- the main migration.
-- =============================================================================

-- HB 693: Affirming Families First Act
select public.seed_bill(
  'hb693', 'HB 693', 'house',
  'Affirming Families First Act',
  'Enact the Affirming Families First Act',
  'Parental Rejection Shield',
  'Shields parents who reject a child''s trans identity from abuse/neglect charges. Redefines ''affirmation'' as acknowledging sex at birth only. Includes right to seek conversion-style therapy.',
  'anti', 'in-committee', 2,
  jsonb_build_object('0', 'Feb 10, 2026', '1', 'Feb 18, 2026', '2', 'Mar 25, 2026'),
  'Rep. Gary Click (R-88), Rep. Josh Williams (R-44)',
  '2nd hearing (proponent testimony) in House Judiciary — March 25, 2026',
  'Opponent testimony expected next',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hb693',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hb693/00_IN/pdf/',
  '/issues/hb693',
  array['youth-family', 'anti-trans']
);

-- HB 798: Privacy Protection Act
select public.seed_bill(
  'hb798', 'HB 798', 'house',
  'Privacy Protection Act',
  'Enact the Privacy Protection Act',
  'Omnibus Anti-Trans Bill',
  'Unusually broad: sex-segregated facilities, school name/pronoun mandates, government document restrictions, and private right of action for facility violations.',
  'anti', 'introduced', 0,
  jsonb_build_object('0', 'Mar 31, 2026'),
  'Rep. Josh Williams (R-44)',
  'Introduced — March 31, 2026',
  'Awaiting committee assignment',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hb798',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hb798/00_IN/pdf/',
  '/issues/hb798',
  array['anti-trans', 'education-dei', 'corrections']
);

-- HB 796: Inmate Housing by Biological Sex
select public.seed_bill(
  'hb796', 'HB 796', 'house',
  'Inmate Housing by Biological Sex',
  'Ensure inmates, prisoners housed according to biological sex',
  'Prison Trans Housing Ban',
  'Requires incarcerated people be housed ''in accordance with their biological sex,'' overriding individualized safety assessments for transgender inmates.',
  'anti', 'introduced', 0,
  jsonb_build_object('0', 'Mar 25, 2026'),
  'Rep. Josh Williams (R-44)',
  'Introduced — March 25, 2026',
  'Awaiting committee assignment',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hb796',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hb796/00_IN/pdf/',
  '/issues/hb796',
  array['corrections', 'anti-trans']
);

-- HB 190: Given Name Act
select public.seed_bill(
  'hb190', 'HB 190', 'house',
  'Given Name Act',
  'Enact the Given Name Act',
  'Forced Outing / Pronoun Ban',
  'Restricts names and pronouns in schools. Requires staff to report student gender-identity accommodation requests to parents. Penalties include 10% withholding of state foundation aid.',
  'anti', 'in-committee', 2,
  jsonb_build_object('0', 'Mar 24, 2025', '1', 'Mar 26, 2025', '2', 'Apr 29, 2025'),
  'Rep. Johnathan Newman (R-80), Rep. Josh Williams (R-44)',
  '1st hearing in House Education — April 29, 2025',
  'Additional hearings expected',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hb190',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hb190/00_IN/pdf/',
  '/issues/hb190',
  array['education-dei', 'anti-trans']
);

-- HB 155: Prohibit DEI in Public Schools
select public.seed_bill(
  'hb155', 'HB 155', 'house',
  'Prohibit DEI in Public Schools',
  'Prohibit diversity, equity, and inclusion in public schools',
  'K–12 DEI Ban',
  'Prohibits DEI programs in schools. Explicitly reaches contracting around sexual orientation, gender identity, and gender expression — banning LGBTQIA+-inclusive programming.',
  'anti', 'in-committee', 2,
  jsonb_build_object('0', 'Mar 6, 2025', '1', 'Mar 19, 2025', '2', 'May 20, 2025'),
  'Rep. Beth Lear (R-61), Rep. Josh Williams (R-44)',
  '2nd hearing in House Education — May 20, 2025',
  'Additional hearings expected',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hb155',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hb155/00_IN/pdf/',
  '/issues/hb155',
  array['education-dei']
);

-- SB 113: Prohibit DEI in Public Schools (Senate)
select public.seed_bill(
  'sb113', 'SB 113', 'senate',
  'Prohibit DEI in Public Schools (Senate)',
  'Prohibit diversity, equity, and inclusion in public schools',
  'Senate DEI Ban',
  'Senate companion to HB 155. Requires school boards to prohibit DEI structures, trainings, offices, and contracting. Suppresses LGBTQIA+-inclusive initiatives.',
  'anti', 'in-committee', 2,
  jsonb_build_object('2', 'Mar 25, 2026'),
  'Sen. Andrew Brenner (R-19)',
  '2nd hearing in Senate Education — March 25, 2026',
  'Additional hearings expected',
  null,
  'https://www.legislature.ohio.gov/legislation/136/sb113',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/sb113/00_IN/pdf/',
  '/issues/sb113',
  array['education-dei']
);

-- HB 172: Minor Mental Health Consent
select public.seed_bill(
  'hb172', 'HB 172', 'house',
  'Minor Mental Health Consent',
  'Prohibit mental health service to minors without parental consent',
  'Youth Therapy Consent Rollback',
  'Removes ability of minors (14+) to access limited outpatient mental health services without parental consent. Threatens LGBTQ youth who need confidential care.',
  'anti', 'in-committee', 2,
  jsonb_build_object('0', 'Mar 12, 2025', '1', 'Mar 19, 2025', '2', 'Nov 19, 2025'),
  'Rep. Johnathan Newman (R-80)',
  'Opponent testimony in House Health — November 19, 2025',
  'Additional hearings or committee vote',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hb172',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hb172/00_IN/pdf/',
  '/issues/hb172',
  array['youth-family']
);

-- HB 196: Candidate Name Disclosure
select public.seed_bill(
  'hb196', 'HB 196', 'house',
  'Candidate Name Disclosure',
  'Regards candidate nomination protests, names on candidacy forms',
  'Deadnaming Candidates Bill',
  'Expands candidate ''former legal names'' disclosure and protest mechanisms. Disproportionately impacts trans candidates, effectively mandating public deadnaming.',
  'anti', 'in-committee', 2,
  jsonb_build_object('0', 'Mar 24, 2025', '1', 'Mar 26, 2025', '2', 'Apr 29, 2025'),
  'Rep. Rodney Creech (R-40), Rep. Angela N. King (R-84)',
  '1st hearing in House General Government — April 29, 2025',
  'Additional hearings expected',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hb196',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hb196/00_IN/pdf/',
  '/issues/hb196',
  array['elections-privacy']
);

-- SB 34: Founding Documents Displays Act
select public.seed_bill(
  'sb34', 'SB 34', 'senate',
  'Founding Documents Displays Act',
  'Enact the Display of Founding Documents of Historic Significance Act',
  'Ten Commandments Classroom Displays',
  'Requires school boards to adopt policies displaying at least four of nine ''founding documents'' — including the Ten Commandments — in social studies and history classrooms. Permits private donors (e.g., the Center for Christian Virtue) to fund displays, inviting religious-right messaging into public schools. Passed the Ohio Senate 23–10 on November 20, 2025.',
  'anti', 'passed-senate', 6,
  jsonb_build_object('0', 'Feb 2025', '3', 'Apr 8, 2025', '4', 'Nov 20, 2025', '5', 'Nov 20, 2025', '6', 'Feb 4, 2026'),
  'Sen. Terry Johnson (R-14)',
  'Referred to House Education Committee — February 4, 2026',
  'Awaiting House committee hearing',
  null,
  'https://www.legislature.ohio.gov/legislation/136/sb34',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/sb34/00_IN/pdf/',
  '/issues/sb34',
  array['education-dei']
);

-- HB 602: State Flag Display Restriction
select public.seed_bill(
  'hb602', 'HB 602', 'house',
  'State Flag Display Restriction',
  'Limit types of flags that state agencies may display on grounds or buildings',
  'Pride Flag Ban on State Property',
  'Limits flags on state-owned property to the U.S., Ohio, POW/MIA, and pre-approved agency flags — effectively banning Pride flags from state buildings and grounds. Revives language that Gov. DeWine line-item-vetoed from the FY26-27 budget (HB 96).',
  'anti', 'in-committee', 2,
  jsonb_build_object('0', 'Nov 18, 2025', '2', 'Mar 30, 2026'),
  'Rep. D.J. Swearingen (R-89), Rep. Rodney Creech (R-40)',
  'Sponsor testimony in House General Government — week of March 30, 2026',
  'Additional hearings expected',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hb602',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hb602/00_IN/pdf/',
  '/issues/hb602',
  array['expression']
);

-- SB 274: Minor Mental Health Consent (Senate)
select public.seed_bill(
  'sb274', 'SB 274', 'senate',
  'Minor Mental Health Consent (Senate)',
  'Prohibit mental health service to minors without parental consent',
  'Senate Companion to HB 172',
  'Senate companion to HB 172. Repeals ORC 5122.04, eliminating the 1989-era provision that allows minors 14+ to access up to six outpatient mental-health sessions without parental consent. Closes a critical confidential-care pathway for LGBTQ+ youth.',
  'anti', 'in-committee', 1,
  jsonb_build_object('0', 'Sep 30, 2025', '1', 'Oct 1, 2025'),
  'Sen. Jerry Cirino (R-18), Sen. Andrew Brenner (R-19)',
  'Referred to Senate Health Committee — October 1, 2025',
  'Awaiting committee hearing',
  null,
  'https://www.legislature.ohio.gov/legislation/136/sb274',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/sb274/00_IN/pdf/',
  '/issues/sb274',
  array['youth-family']
);

-- HB 457: Politically-Motivated Crimes
select public.seed_bill(
  'hb457', 'HB 457', 'house',
  'Politically-Motivated Crimes',
  'Create enhanced penalties for politically motivated offenses',
  'Sexual Orientation Aggravator Removal',
  'Creates new aggravated-murder offenses for politically motivated violence and mandatory prison terms. Adds ''biological sex'' as an aggravating factor while removing ''sexual orientation'' from Ohio''s existing aggravating-factor list — a net loss for LGBTQ+ protections.',
  'anti', 'in-committee', 1,
  '{}'::jsonb,
  'Rep. Jack K. Daniels (R-32), Rep. Josh Williams (R-44)',
  'Referred to House Criminal Justice Committee',
  'Awaiting committee hearing',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hb457',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hb457/00_IN/pdf/',
  '/issues/hb457',
  array['civil-rights', 'anti-trans']
);

-- HB 262: Designate Natural Family Month
select public.seed_bill(
  'hb262', 'HB 262', 'house',
  'Designate Natural Family Month',
  'Designate Natural Family Month',
  'Anti-LGBTQ Family Framing',
  'Establishes ''Natural Family Month'' promoting a heteronormative ''one biological born man, woman'' family structure — excluding same-sex parents and nontraditional families.',
  'anti', 'in-committee', 2,
  jsonb_build_object('0', 'May 13, 2025', '1', 'May 14, 2025', '2', 'Sep 30, 2025'),
  'Rep. Beth Lear (R-61), Rep. Josh Williams (R-44)',
  'Proponent testimony — September 30, 2025',
  'Additional hearings or committee vote',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hb262',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hb262/00_IN/pdf/',
  '/issues/hb262',
  array['youth-family']
);

-- SB 70: Ohio Fairness Act
select public.seed_bill(
  'sb70', 'SB 70', 'senate',
  'Ohio Fairness Act',
  'Enact the Ohio Fairness Act regarding nondiscrimination protections',
  'Statewide Nondiscrimination Protections',
  'Adds sexual orientation and gender identity to Ohio''s existing nondiscrimination statutes, covering employment, housing, and public accommodations statewide.',
  'pro', 'in-committee', 1,
  jsonb_build_object('0', 'Feb 11, 2025', '1', 'Feb 19, 2025'),
  'Sen. Nickie Antonio (D-23)',
  'Referred to Senate Judiciary Committee',
  'Awaiting committee hearing',
  null,
  'https://www.legislature.ohio.gov/legislation/136/sb70',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/sb70/00_IN/pdf/',
  '/issues/sb70',
  array['civil-rights']
);

-- HB 136: Ohio Fairness Act (House)
select public.seed_bill(
  'hb136', 'HB 136', 'house',
  'Ohio Fairness Act (House)',
  'Enact the Ohio Fairness Act regarding nondiscrimination protections',
  'House Nondiscrimination Companion',
  'House companion to SB 70. Extends Ohio''s civil rights protections to include sexual orientation and gender identity across employment, housing, and public accommodations.',
  'pro', 'in-committee', 1,
  jsonb_build_object('0', 'Feb 25, 2025', '1', 'Mar 5, 2025'),
  'Rep. Tristan Rader (D-13), Rep. Crystal Lett (D-11)',
  'Referred to House Judiciary Committee — March 5, 2025',
  'Awaiting committee hearing',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hb136',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hb136/00_IN/pdf/',
  '/issues/hb136',
  array['civil-rights']
);

-- SB 71: Conversion Therapy Ban
select public.seed_bill(
  'sb71', 'SB 71', 'senate',
  'Conversion Therapy Ban',
  'Prohibit licensed professionals from practicing conversion therapy on minors',
  'Protect LGBTQ+ Youth from Conversion Therapy',
  'Prohibits state-licensed mental health professionals from subjecting minors to conversion therapy — a discredited practice rejected by every major medical association.',
  'pro', 'in-committee', 1,
  jsonb_build_object('0', 'Feb 11, 2025', '1', 'Feb 19, 2025'),
  'Sen. Nickie Antonio (D-23)',
  'Referred to Senate Health Committee',
  'Awaiting committee hearing',
  null,
  'https://www.legislature.ohio.gov/legislation/136/sb71',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/sb71/00_IN/pdf/',
  '/issues/sb71',
  array['healthcare', 'youth-family']
);

-- HB 300: Conversion Therapy Ban (House)
select public.seed_bill(
  'hb300', 'HB 300', 'house',
  'Conversion Therapy Ban (House)',
  'Prohibit licensed professionals from practicing conversion therapy on minors',
  'House Conversion Therapy Companion',
  'House companion to SB 71. Bans conversion therapy on minors by licensed professionals. Supported by the American Medical Association, American Psychological Association, and American Academy of Pediatrics.',
  'pro', 'introduced', 1,
  jsonb_build_object('0', 'May 21, 2025', '1', 'May 28, 2025'),
  'Rep. Karen Brownlee (D-28), Rep. Crystal Lett (D-11)',
  'Referred to House Health Committee — May 28, 2025',
  'Awaiting committee hearing',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hb300',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hb300/00_IN/pdf/',
  '/issues/hb300',
  array['healthcare', 'youth-family']
);

-- SB 211: Love Makes a Family Week
select public.seed_bill(
  'sb211', 'SB 211', 'senate',
  'Love Makes a Family Week',
  'Designate Love Makes a Family Week in Ohio',
  'Celebrate Diverse Ohio Families',
  'Designates a week celebrating the diversity of Ohio families — including LGBTQ+ families, adoptive families, and nontraditional households. A direct counterpoint to HB 262''s ''Natural Family Month.''',
  'pro', 'introduced', 0,
  jsonb_build_object('0', 'Oct 14, 2025'),
  'Sen. Nickie Antonio (D-23)',
  'Introduced — October 14, 2025',
  'Awaiting committee assignment',
  null,
  'https://www.legislature.ohio.gov/legislation/136/sb211',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/sb211/00_IN/pdf/',
  '/issues/sb211',
  array['youth-family']
);

-- HB 327: PRIDE Act
select public.seed_bill(
  'hb327', 'HB 327', 'house',
  'PRIDE Act',
  'Enact the Parental Rights in Diverse Environments Act',
  'Parental Rights for Affirming Families',
  'Protects parents who affirm and support their LGBTQ+ children from state interference. Ensures affirming parenting decisions cannot be used as grounds for custody challenges or abuse allegations.',
  'pro', 'in-committee', 1,
  jsonb_build_object('0', 'Jun 3, 2025', '1', 'Jun 11, 2025'),
  'Rep. Karen Brownlee (D-28), Rep. Darnell Brewer (D-23)',
  'Referred to House Children and Human Services Committee — June 11, 2025',
  'Awaiting committee hearing',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hb327',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hb327/00_IN/pdf/',
  '/issues/hb327',
  array['youth-family', 'civil-rights']
);

-- HJR 4: Marriage Equality Act
select public.seed_bill(
  'hjr4', 'HJR 4', 'house',
  'Marriage Equality Act',
  'Amend Article XV Section 11 of the Constitution of Ohio regarding marriage',
  'Repeal Ohio''s 2004 Same-Sex Marriage Ban',
  'Constitutional amendment to repeal Ohio''s dormant 2004 same-sex marriage ban and recognize the right to interracial marriage in the Ohio Constitution. Would let Ohio voters codify marriage equality independent of federal precedent. No committee hearings have been held to date.',
  'pro', 'in-committee', 1,
  jsonb_build_object('0', 'Jun 3, 2025', '1', 'Jun 2025'),
  'Rep. Eric Synenberg (D-22), Rep. Anita Somani (D-11)',
  'Referred to House Judiciary Committee — June 2025',
  'Awaiting committee hearing',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hjr4',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hjr4/00_IN/pdf/',
  '/issues/hjr4',
  array['civil-rights']
);

-- HB 306: Hate Crimes Act
select public.seed_bill(
  'hb306', 'HB 306', 'house',
  'Hate Crimes Act',
  'Enact the Ohio Hate Crimes Act',
  'Hate Crimes — Excludes Trans Protections',
  'Creates enhanced penalties for hate crimes based on race, religion, national origin, disability, and sexual orientation — but notably excludes gender identity, leaving transgender Ohioans without protection.',
  'mixed', 'in-committee', 2,
  jsonb_build_object('0', 'May 27, 2025', '1', 'Jun 4, 2025', '2', 'Feb 25, 2026'),
  'Rep. Brett Hillyer (R-37), Rep. Bride Rose Sweeney (D-16)',
  '1st hearing in House Criminal Justice Committee — February 25, 2026',
  'Additional hearings expected',
  null,
  'https://www.legislature.ohio.gov/legislation/136/hb306',
  'https://search-prod.lis.state.oh.us/api/v2/general_assembly_136/legislation/hb306/00_IN/pdf/',
  '/issues/hb306',
  array['civil-rights']
);
