-- =============================================================================
-- Ohio Pride PAC - Migration 3: Bill Tracker
-- -----------------------------------------------------------------------------
-- Moves the legislative bill tracker out of /js/bill-data.js and into a
-- proper relational schema. This unlocks three things that are not possible
-- with the current JS array:
--
--   1. Non-developer updates. A campaigns staffer can mark a bill as
--      "passed-senate" by editing one row in the Supabase dashboard,
--      without touching code or triggering a deploy.
--
--   2. Query-based pages. "Show me all anti-LGBTQ+ bills that passed a
--      chamber in 2026" becomes a one-line query instead of a page-specific
--      JavaScript filter. This enables the scorecard, weekly digest emails,
--      and any future alerting pipeline.
--
--   3. Consistent taxonomy. Categories and pipeline steps are their own
--      tables, which means their labels, colors, and ordering live in ONE
--      place. Rename "Anti-Trans" to "Gender Identity" and every bill that
--      uses the category picks up the change without migration.
--
-- This migration depends on migrations 1 and 2 already being applied
-- (specifically, the `set_updated_at()` trigger function).
-- =============================================================================


-- =============================================================================
-- TABLE: bill_categories
-- -----------------------------------------------------------------------------
-- Reference table for the topic taxonomy (Anti-Trans, Education / DEI,
-- Expression, Healthcare, etc.). A category has a stable slug for use in
-- URLs and code, a human-readable label for display, and a brand color for
-- the category badge on bill cards.
--
-- The colors currently live hardcoded in /issues.html as a `catColors` JS
-- object. Moving them here means a designer can adjust the palette without
-- a code change.
-- =============================================================================
create table if not exists public.bill_categories (
  id             uuid          primary key default gen_random_uuid(),
  slug           text          not null unique,                -- e.g. "anti-trans"
  label          text          not null,                       -- e.g. "Anti-Trans"
  color_hex      text          not null default '#6b7280'      -- e.g. "#e879f9"
                   check (color_hex ~ '^#[0-9a-fA-F]{6}$'),
  description    text,                                         -- one-line topic summary
  display_order  integer       not null default 100,
  is_active      boolean       not null default true,
  created_at     timestamptz   not null default now(),
  updated_at     timestamptz   not null default now()
);

comment on table public.bill_categories is
  'Taxonomy of policy topics used to tag bills. Category colors drive badge styling on the issues page.';
comment on column public.bill_categories.color_hex is
  'Hex color used for the category badge. Validated by CHECK constraint to be a valid 6-digit hex.';

create index if not exists bill_categories_active_order_idx
  on public.bill_categories (is_active, display_order);

drop trigger if exists set_bill_categories_updated_at on public.bill_categories;
create trigger set_bill_categories_updated_at
  before update on public.bill_categories
  for each row execute function public.set_updated_at();


-- =============================================================================
-- TABLE: bill_pipeline_steps
-- -----------------------------------------------------------------------------
-- The numbered stages a bill goes through on its way to becoming law. Each
-- step is scoped to a chamber (house or senate) because the sequence differs
-- depending on which chamber a bill was introduced in.
--
-- Example: a House bill at step 5 means "Sent to Senate", but a Senate bill
-- at step 5 means "Sent to House". The `chamber` column plus `step_index`
-- together form a composite key that uniquely identifies each step label.
--
-- This table replaces the HOUSE_STEPS and SENATE_STEPS arrays currently
-- hardcoded in /js/bill-pipeline.js.
-- =============================================================================
create table if not exists public.bill_pipeline_steps (
  id           uuid          primary key default gen_random_uuid(),
  chamber      text          not null check (chamber in ('house', 'senate')),
  step_index   integer       not null check (step_index >= 0),
  label        text          not null,
  description  text,                                    -- optional tooltip text
  is_terminal  boolean       not null default false,   -- last step in the pipeline (Governor)?
  created_at   timestamptz   not null default now(),
  updated_at   timestamptz   not null default now(),
  unique (chamber, step_index)
);

comment on table public.bill_pipeline_steps is
  'Ordered legislative stages per chamber. (chamber, step_index) is the lookup key used by bill.current_step.';

drop trigger if exists set_bill_pipeline_steps_updated_at on public.bill_pipeline_steps;
create trigger set_bill_pipeline_steps_updated_at
  before update on public.bill_pipeline_steps
  for each row execute function public.set_updated_at();


-- =============================================================================
-- TABLE: bill_statuses
-- -----------------------------------------------------------------------------
-- Named status values with their display labels and colors. These are the
-- same values that appear as data-status attributes on bill cards and power
-- the filter buttons at the top of the issues page.
--
-- The current site has seven status values hardcoded as CSS variables
-- (--status-introduced, --status-committee, --status-passed-committee,
-- --status-passed-chamber, --status-senate, --status-law, --status-dead).
-- Putting them in a table means a new status like "vetoed" or "enrolled"
-- can be added without a code change.
-- =============================================================================
create table if not exists public.bill_statuses (
  id             uuid          primary key default gen_random_uuid(),
  slug           text          not null unique,                -- e.g. "passed-house"
  label          text          not null,                       -- e.g. "Passed House → In Senate"
  short_label    text,                                         -- for filter buttons, e.g. "Passed House"
  color_hex      text          not null default '#6b7280'
                   check (color_hex ~ '^#[0-9a-fA-F]{6}$'),
  is_dead        boolean       not null default false,         -- bill is no longer moving
  is_law         boolean       not null default false,         -- bill has been signed
  display_order  integer       not null default 100,
  is_active      boolean       not null default true,
  created_at     timestamptz   not null default now(),
  updated_at    timestamptz    not null default now()
);

comment on table public.bill_statuses is
  'Named status values used for bill cards and filter UI. `is_dead` and `is_law` flags allow queries like "all enacted laws" or "all killed bills" without string matching on the slug.';

create index if not exists bill_statuses_active_order_idx
  on public.bill_statuses (is_active, display_order);

drop trigger if exists set_bill_statuses_updated_at on public.bill_statuses;
create trigger set_bill_statuses_updated_at
  before update on public.bill_statuses
  for each row execute function public.set_updated_at();


-- =============================================================================
-- TABLE: bills
-- -----------------------------------------------------------------------------
-- The main bill record. One row per tracked piece of legislation. Every
-- field here corresponds to a field on the current /js/bill-data.js records.
--
-- Design notes on specific columns:
--
-- `slug` replaces the `id` field in bill-data.js (e.g. "hb249", "sb70"). It
--   is used in URLs (/issues/hb249) and must be unique across all bills
--   regardless of chamber or session.
--
-- `general_assembly` captures the Ohio Legislature session number (currently
--   136). Bills from different sessions can share a number (HB 249 in the
--   136th GA is different from HB 249 in the 137th GA), so this column plus
--   `bill_number` together identify the bill in Ohio's system.
--
-- `stance` is the organization's editorial position: anti, pro, or mixed.
--   This drives the section headers on the issues page and the color of the
--   bill-card accent.
--
-- `status_id` is a foreign key into bill_statuses. We store the status as a
--   FK rather than an enum so new statuses can be added without DDL changes.
--
-- `chamber` and `current_step_index` together identify the bill's current
--   position on the legislative pipeline. They reference bill_pipeline_steps
--   via (chamber, step_index).
--
-- `pipeline_dates` is a jsonb object mapping step_index to an ISO date
--   string, preserving the structure in bill-data.js exactly. We could
--   normalize this into a `bill_actions` log table, but the current site
--   only uses it to render the pipeline visualization, so a denormalized
--   jsonb column is simpler and adequate for today. Adding a proper actions
--   log later is additive, not a breaking change.
--
-- `danger_step_index` supports the pipeline renderer's "mark a step as
--   danger instead of current" feature, used when a bill is about to hit a
--   critical moment (scheduled floor vote tomorrow, governor's desk, etc.).
-- =============================================================================
create table if not exists public.bills (
  id                  uuid          primary key default gen_random_uuid(),

  -- Identity
  slug                text          not null unique,                      -- hb249, sb70
  bill_number         text          not null,                             -- "HB 249", "SB 70"
  general_assembly    integer       not null default 136,                 -- Ohio GA session number
  chamber             text          not null check (chamber in ('house', 'senate')),

  -- Titles and summary
  title               text          not null,                             -- short editorial title
  official_title      text          not null,                             -- as filed with the legislature
  nickname            text,                                               -- informal name, e.g. "Drag Ban"
  description         text          not null,                             -- 1-2 sentence summary

  -- Editorial position
  stance              text          not null check (stance in ('anti', 'pro', 'mixed')),

  -- Current state
  status_id           uuid          not null references public.bill_statuses(id)
                                    on update cascade on delete restrict,
  current_step_index  integer       not null default 0 check (current_step_index >= 0),
  danger_step_index   integer       check (danger_step_index >= 0),       -- nullable; null = normal state
  pipeline_dates      jsonb         not null default '{}'::jsonb,         -- { "0": "Apr 29, 2025", "1": "May 7, 2025" }

  -- Sponsorship and action
  sponsors            text          not null,                             -- free text, e.g. "Rep. King (R-84), Rep. Williams (R-44)"
  last_action         text          not null,                             -- free text display
  next_date           text,                                               -- free text, e.g. "Awaiting committee hearing"
  house_vote          text,                                               -- free text, e.g. "Passed 63-32 on March 25, 2026"
  senate_vote         text,                                               -- parallel column for future use

  -- External links
  legislature_url     text          not null,                             -- official Ohio Legislature page
  text_url            text,                                               -- direct PDF of the bill text
  internal_url        text,                                               -- our own detail page, e.g. /issues/hb249

  -- Lifecycle and sorting
  introduced_date     date,                                               -- optional, ISO date
  is_featured         boolean       not null default false,               -- pin to top of listings
  is_active           boolean       not null default true,                -- soft-delete for retired/withdrawn bills
  display_order       integer       not null default 100,                 -- manual override within stance groups

  -- Audit
  created_at          timestamptz   not null default now(),
  updated_at          timestamptz   not null default now()
);

comment on table public.bills is
  'Tracked pieces of LGBTQ+ legislation. Replaces the BILLS array in /js/bill-data.js.';
comment on column public.bills.pipeline_dates is
  'Map of step_index to date-string for pipeline visualization. Denormalized summary; could be backed by a future bill_actions log.';
comment on column public.bills.danger_step_index is
  'When set, overrides the "current" visual state on the pipeline to show the step in red instead of blue. Use for bills at a critical moment.';

create index if not exists bills_active_stance_idx     on public.bills (is_active, stance, display_order);
create index if not exists bills_status_idx            on public.bills (status_id);
create index if not exists bills_chamber_step_idx      on public.bills (chamber, current_step_index);
create index if not exists bills_general_assembly_idx  on public.bills (general_assembly);

drop trigger if exists set_bills_updated_at on public.bills;
create trigger set_bills_updated_at
  before update on public.bills
  for each row execute function public.set_updated_at();


-- =============================================================================
-- TABLE: bill_category_assignments
-- -----------------------------------------------------------------------------
-- Join table for the many-to-many relationship between bills and categories.
-- A bill can be tagged with multiple categories (e.g. HB 249 is both
-- "Expression" and "Anti-Trans"), and a category can be applied to many
-- bills. This is the standard relational pattern for that relationship.
--
-- The composite primary key on (bill_id, category_id) prevents duplicate
-- assignments, and the ON DELETE CASCADE means removing a bill cleanly
-- removes its category tags. Removing a category is RESTRICT-ed to prevent
-- accidentally orphaning assignments.
-- =============================================================================
create table if not exists public.bill_category_assignments (
  bill_id       uuid  not null references public.bills(id)            on delete cascade,
  category_id   uuid  not null references public.bill_categories(id)  on delete restrict,
  created_at    timestamptz not null default now(),
  primary key (bill_id, category_id)
);

comment on table public.bill_category_assignments is
  'Many-to-many link between bills and policy categories.';

create index if not exists bill_category_assignments_category_idx
  on public.bill_category_assignments (category_id);


-- =============================================================================
-- VIEW: bills_public
-- -----------------------------------------------------------------------------
-- The single query the public /issues page needs. Joins bills to their
-- status, their pipeline step label, and an aggregated array of category
-- objects in one call. The Netlify function just selects from this view
-- and returns the result as JSON.
--
-- We use a view rather than a function because views can be selected from
-- directly via PostgREST, which the Supabase client uses under the hood.
-- That means the front-end can filter and order the result without us
-- having to write a custom endpoint for every combination.
-- =============================================================================
create or replace view public.bills_public as
select
  b.id,
  b.slug,
  b.bill_number,
  b.general_assembly,
  b.chamber,
  b.title,
  b.official_title,
  b.nickname,
  b.description,
  b.stance,
  b.current_step_index,
  b.danger_step_index,
  b.pipeline_dates,
  b.sponsors,
  b.last_action,
  b.next_date,
  b.house_vote,
  b.senate_vote,
  b.legislature_url,
  b.text_url,
  b.internal_url,
  b.introduced_date,
  b.is_featured,
  b.display_order,

  -- Status object
  jsonb_build_object(
    'slug',        s.slug,
    'label',       s.label,
    'short_label', s.short_label,
    'color_hex',   s.color_hex,
    'is_dead',     s.is_dead,
    'is_law',      s.is_law
  ) as status,

  -- Current pipeline step object (may be null if the step_index does not
  -- correspond to a defined step, which should not happen in practice).
  (
    select jsonb_build_object(
      'chamber',     ps.chamber,
      'step_index',  ps.step_index,
      'label',       ps.label,
      'is_terminal', ps.is_terminal
    )
    from public.bill_pipeline_steps ps
    where ps.chamber = b.chamber and ps.step_index = b.current_step_index
    limit 1
  ) as current_step,

  -- Categories as a sorted array of objects. coalesce to an empty array so
  -- the JSON shape is predictable even for bills with no categories.
  coalesce(
    (
      select jsonb_agg(
        jsonb_build_object(
          'slug',      c.slug,
          'label',     c.label,
          'color_hex', c.color_hex
        )
        order by c.display_order, c.label
      )
      from public.bill_category_assignments bca
      join public.bill_categories c on c.id = bca.category_id and c.is_active
      where bca.bill_id = b.id
    ),
    '[]'::jsonb
  ) as categories

from public.bills b
join public.bill_statuses s on s.id = b.status_id
where b.is_active = true;

comment on view public.bills_public is
  'Denormalized read-only projection of bills with status, current step, and categories pre-joined. Safe for public (anon) read access.';


-- =============================================================================
-- RLS + GRANTS
-- =============================================================================
alter table public.bill_categories              enable row level security;
alter table public.bill_pipeline_steps          enable row level security;
alter table public.bill_statuses                enable row level security;
alter table public.bills                        enable row level security;
alter table public.bill_category_assignments    enable row level security;

-- Public reads of active rows
drop policy if exists "bill_categories read active" on public.bill_categories;
create policy "bill_categories read active"
  on public.bill_categories for select to anon, authenticated
  using (is_active = true);

drop policy if exists "bill_pipeline_steps read all" on public.bill_pipeline_steps;
create policy "bill_pipeline_steps read all"
  on public.bill_pipeline_steps for select to anon, authenticated
  using (true);

drop policy if exists "bill_statuses read active" on public.bill_statuses;
create policy "bill_statuses read active"
  on public.bill_statuses for select to anon, authenticated
  using (is_active = true);

drop policy if exists "bills read active" on public.bills;
create policy "bills read active"
  on public.bills for select to anon, authenticated
  using (is_active = true);

drop policy if exists "bill_category_assignments read all" on public.bill_category_assignments;
create policy "bill_category_assignments read all"
  on public.bill_category_assignments for select to anon, authenticated
  using (true);

-- Service-role writes only
drop policy if exists "bill_categories service_role writes" on public.bill_categories;
create policy "bill_categories service_role writes"
  on public.bill_categories for all to service_role using (true) with check (true);

drop policy if exists "bill_pipeline_steps service_role writes" on public.bill_pipeline_steps;
create policy "bill_pipeline_steps service_role writes"
  on public.bill_pipeline_steps for all to service_role using (true) with check (true);

drop policy if exists "bill_statuses service_role writes" on public.bill_statuses;
create policy "bill_statuses service_role writes"
  on public.bill_statuses for all to service_role using (true) with check (true);

drop policy if exists "bills service_role writes" on public.bills;
create policy "bills service_role writes"
  on public.bills for all to service_role using (true) with check (true);

drop policy if exists "bill_category_assignments service_role writes" on public.bill_category_assignments;
create policy "bill_category_assignments service_role writes"
  on public.bill_category_assignments for all to service_role using (true) with check (true);

-- View grant
grant select on public.bills_public to anon, authenticated;


-- =============================================================================
-- SEED: bill_categories
-- -----------------------------------------------------------------------------
-- Colors copied from the catColors object in /issues.html. Descriptions are
-- new and can be edited in the Supabase dashboard.
-- =============================================================================
insert into public.bill_categories (slug, label, color_hex, description, display_order) values
  ('anti-trans',           'Anti-Trans',          '#e879f9',
     'Legislation targeting transgender Ohioans in healthcare, sports, education, or identity documents.', 10),
  ('civil-rights',         'Civil Rights',        '#38bdf8',
     'Nondiscrimination protections in employment, housing, and public accommodations.', 20),
  ('education-dei',        'Education / DEI',     '#60a5fa',
     'Curriculum, classroom speech, library content, DEI programs, and school policy.', 30),
  ('expression',           'Expression',          '#fb923c',
     'Bills affecting drag performance, public expression, or obscenity definitions.', 40),
  ('youth-family',         'Youth / Family',      '#2dd4bf',
     'Legislation affecting LGBTQ+ youth, parental rights, or family formation.', 50),
  ('elections-privacy',    'Elections / Privacy', '#a78bfa',
     'Voter identification, privacy protections, and election participation.', 60),
  ('healthcare',           'Healthcare',          '#34d399',
     'Medical care, gender-affirming treatment, insurance coverage, and provider licensing.', 70),
  ('corrections',          'Corrections',         '#94a3b8',
     'Incarcerated LGBTQ+ Ohioans: housing placement, medical care, and access.', 80)
on conflict (slug) do nothing;


-- =============================================================================
-- SEED: bill_pipeline_steps
-- -----------------------------------------------------------------------------
-- Copied directly from the HOUSE_STEPS and SENATE_STEPS arrays in
-- /js/bill-pipeline.js. Nine steps per chamber; the last (Governor) is
-- terminal.
-- =============================================================================
insert into public.bill_pipeline_steps (chamber, step_index, label, is_terminal) values
  ('house',  0, 'Introduced',              false),
  ('house',  1, 'Referred to Committee',   false),
  ('house',  2, 'Committee Hearings',      false),
  ('house',  3, 'Reported from Committee', false),
  ('house',  4, 'House Floor Vote',        false),
  ('house',  5, 'Sent to Senate',          false),
  ('house',  6, 'Senate Committee',        false),
  ('house',  7, 'Senate Floor Vote',       false),
  ('house',  8, 'Governor',                true),
  ('senate', 0, 'Introduced',              false),
  ('senate', 1, 'Referred to Committee',   false),
  ('senate', 2, 'Committee Hearings',      false),
  ('senate', 3, 'Reported from Committee', false),
  ('senate', 4, 'Senate Floor Vote',       false),
  ('senate', 5, 'Sent to House',           false),
  ('senate', 6, 'House Committee',         false),
  ('senate', 7, 'House Floor Vote',        false),
  ('senate', 8, 'Governor',                true)
on conflict (chamber, step_index) do nothing;


-- =============================================================================
-- SEED: bill_statuses
-- -----------------------------------------------------------------------------
-- The status values that appear on the current issues page plus a few
-- future-proofing additions (vetoed, enrolled, withdrawn) so those become
-- available without a schema change the first time they are needed.
-- =============================================================================
insert into public.bill_statuses (slug, label, short_label, color_hex, is_dead, is_law, display_order) values
  ('introduced',       'Introduced',                   'Introduced',        '#3b82f6', false, false, 10),
  ('in-committee',     'In Committee',                 'In Committee',      '#f59e0b', false, false, 20),
  ('passed-committee', 'Passed Committee',             'Passed Committee',  '#f97316', false, false, 30),
  ('passed-house',     'Passed House → In Senate',     'Passed House',      '#dc2626', false, false, 40),
  ('passed-senate',    'Passed Senate → In House',     'Passed Senate',     '#dc2626', false, false, 50),
  ('passed-chamber',   'Passed One Chamber',           'Passed Chamber',    '#ef4444', false, false, 60),
  ('enrolled',         'Enrolled → To Governor',       'Enrolled',          '#b91c1c', false, false, 70),
  ('signed-into-law',  'Signed Into Law',              'Signed',            '#991b1b', false, true,  80),
  ('vetoed',           'Vetoed',                       'Vetoed',            '#6b7280', true,  false, 85),
  ('withdrawn',        'Withdrawn',                    'Withdrawn',         '#6b7280', true,  false, 90),
  ('dead',             'Dead',                         'Dead',              '#6b7280', true,  false, 95)
on conflict (slug) do nothing;


-- =============================================================================
-- SEED HELPER: bills and their category assignments
-- -----------------------------------------------------------------------------
-- We seed all 22 bills from /js/bill-data.js in one pass. To keep the SQL
-- readable, we use a DO block that inserts each bill and its category links
-- as a unit, looking up status and category IDs by slug.
--
-- If you re-run this migration, the `on conflict (slug) do nothing` on the
-- bills insert prevents duplicates. The category assignment insert uses
-- `on conflict do nothing` on the composite primary key for the same reason.
-- =============================================================================

-- Convenience function to seed a single bill with its categories.
-- We inline this as a function so the seed block below is compact and
-- readable, and so the logic can be reused when adding new bills
-- programmatically later.
create or replace function public.seed_bill(
  p_slug              text,
  p_bill_number       text,
  p_chamber           text,
  p_title             text,
  p_official_title    text,
  p_nickname          text,
  p_description       text,
  p_stance            text,
  p_status_slug       text,
  p_current_step      integer,
  p_pipeline_dates    jsonb,
  p_sponsors          text,
  p_last_action       text,
  p_next_date         text,
  p_house_vote        text,
  p_legislature_url   text,
  p_text_url          text,
  p_internal_url      text,
  p_category_slugs    text[]
)
returns uuid
language plpgsql
as $$
declare
  v_status_id uuid;
  v_bill_id uuid;
  v_cat_slug text;
  v_cat_id uuid;
begin
  select id into v_status_id from public.bill_statuses where slug = p_status_slug;
  if v_status_id is null then
    raise exception 'seed_bill: unknown status slug %', p_status_slug;
  end if;

  insert into public.bills (
    slug, bill_number, chamber, title, official_title, nickname, description,
    stance, status_id, current_step_index, pipeline_dates,
    sponsors, last_action, next_date, house_vote,
    legislature_url, text_url, internal_url
  ) values (
    p_slug, p_bill_number, p_chamber, p_title, p_official_title, p_nickname, p_description,
    p_stance, v_status_id, p_current_step, coalesce(p_pipeline_dates, '{}'::jsonb),
    p_sponsors, p_last_action, p_next_date, p_house_vote,
    p_legislature_url, p_text_url, p_internal_url
  )
  on conflict (slug) do nothing
  returning id into v_bill_id;

  -- If the bill already existed, fetch its id for the category link step
  if v_bill_id is null then
    select id into v_bill_id from public.bills where slug = p_slug;
  end if;

  -- Attach categories
  if p_category_slugs is not null then
    foreach v_cat_slug in array p_category_slugs loop
      select id into v_cat_id from public.bill_categories where slug = v_cat_slug;
      if v_cat_id is not null then
        insert into public.bill_category_assignments (bill_id, category_id)
        values (v_bill_id, v_cat_id)
        on conflict do nothing;
      end if;
    end loop;
  end if;

  return v_bill_id;
end;
$$;


-- -----------------------------------------------------------------------------
-- SEED: 22 bills from /js/bill-data.js as of April 20, 2026
-- Anti-LGBTQ+ bills first, then mixed, then pro. Ordering inside each
-- stance matches the order on the live site.
-- -----------------------------------------------------------------------------
select public.seed_bill(
  'hb249', 'HB 249', 'house',
  'Indecent Exposure Modernization Act',
  'Enact the Indecent Exposure Modernization Act',
  'Drag Ban',
  'Creates ''unlawful adult cabaret performance'' with a definition reaching gender expression differing from ''biological sex.'' Penalties escalate from misdemeanors to felonies when minors are present.',
  'anti', 'passed-house', 6,
  jsonb_build_object('0', 'Apr 29, 2025', '1', 'May 7, 2025', '3', 'Mar 25, 2026', '4', 'Mar 25, 2026', '5', 'Mar 26, 2026', '6', 'Apr 15, 2026'),
  'Rep. Angela N. King (R-84), Rep. Josh Williams (R-44)',
  'Referred to Senate Judiciary Committee. April 15, 2026',
  'Awaiting first Senate committee hearing',
  'Passed 63-32 on March 25, 2026',
  'https://www.legislature.ohio.gov/legislation/136/hb249',
  null,
  '/issues/hb249',
  array['expression', 'anti-trans']
);

-- The remaining 21 bills follow the same seed_bill() call pattern. To keep
-- this migration file at a manageable length, the rest are seeded via a
-- separate file: seed_bills_additional.sql, which should be run immediately
-- after this migration. The seed_bill() function stays in place permanently
-- because it is also useful for adding new bills going forward.

comment on function public.seed_bill(text, text, text, text, text, text, text, text, text, integer, jsonb, text, text, text, text, text, text, text, text[]) is
  'Upserts a single bill with its category tags. Used by initial seed and available for future bill additions.';
