-- =============================================================================
-- Ohio Pride PAC - Migration 4: Legislative Scorecard
-- -----------------------------------------------------------------------------
-- Moves the scorecard data (legislators, grade scale, roll calls, and the
-- vote exceptions that document crossover votes) from hardcoded JavaScript
-- files into a proper relational schema.
--
-- Architecture note:
--
-- The scorecard has two data layers that the current JS files already
-- separate thoughtfully. The editorial layer is the per-legislator
-- judgments your team maintains by hand: votes score, sponsorship score,
-- news score, and the notes that justify them. The evidence layer is the
-- audit trail of actual roll-call votes and the documented exceptions
-- from party-line defaults. This migration preserves that separation.
--
-- We store the three component scores (v, s, n) as columns on the
-- legislators row rather than as rows in a scores table. This is the
-- simpler and correct choice as long as the scoring methodology is
-- stable; if you ever add a fourth or fifth scoring dimension, adding a
-- column is a small migration.
--
-- For roll calls, we adopt the same party-line-plus-exceptions model the
-- current voting-records.js uses. A roll_calls row records the bill and
-- outcome; a legislator_vote_exceptions row records any legislator whose
-- vote differed from their party-line default. This lets you capture 20
-- exceptions across 10 roll calls with 20 rows instead of 2,640 (132
-- legislators times 20 roll calls).
--
-- Depends on migrations 1-3 having been applied (specifically the
-- set_updated_at trigger function and the bills table, which roll_calls
-- references by slug).
-- =============================================================================


-- =============================================================================
-- TABLE: grade_scale
-- -----------------------------------------------------------------------------
-- The six-row table mapping weighted 0-to-100 scores to letter grades,
-- labels, and colors. Currently the GRADE_SCALE constant in
-- /js/scorecard-data.js. Putting it in a table means the thresholds can
-- be adjusted by non-developers (say, raising the A+ threshold from 90
-- to 92) without a code deploy.
--
-- We use "min_score" as the threshold and define the scale such that a
-- legislator's grade is the row with the highest min_score <= their
-- computed score. This matches the existing JS logic exactly.
-- =============================================================================
create table if not exists public.grade_scale (
  id             uuid          primary key default gen_random_uuid(),
  grade          text          not null unique,              -- "A+", "A", "B", "C", "D", "F"
  label          text          not null,                     -- "Champion", "Strong Ally", etc.
  min_score      integer       not null check (min_score >= 0 and min_score <= 100),
  color_hex      text          not null default '#6b7280'
                   check (color_hex ~ '^#[0-9a-fA-F]{6}$'),
  description    text,
  display_order  integer       not null default 100,
  is_active      boolean       not null default true,
  created_at     timestamptz   not null default now(),
  updated_at     timestamptz   not null default now()
);

comment on table public.grade_scale is
  'Letter grade thresholds for weighted 0-100 scores. Grade is the row with the highest min_score <= computed score.';

-- Prevents two grades from having the same min_score, which would make
-- the grade lookup ambiguous.
create unique index if not exists grade_scale_min_score_idx
  on public.grade_scale (min_score) where is_active = true;

drop trigger if exists set_grade_scale_updated_at on public.grade_scale;
create trigger set_grade_scale_updated_at
  before update on public.grade_scale
  for each row execute function public.set_updated_at();


-- =============================================================================
-- TABLE: legislators
-- -----------------------------------------------------------------------------
-- One row per Ohio state legislator (House and Senate combined). The
-- current JS splits them into HOUSE_MEMBERS and SENATE_MEMBERS arrays,
-- but at the database level there's no reason to have two tables — the
-- `chamber` column distinguishes them and simplifies cross-chamber
-- queries like "show me every legislator who got an F."
--
-- Editorial scoring columns (v, s, n in the JS) are stored in full
-- instead of abbreviated so the meaning is obvious when someone is
-- editing a row in the Supabase dashboard.
--
-- `seated_since` supports the "not seated yet" case in the voting-record
-- resolver: if a legislator took office after a roll call date, their
-- vote on that roll call is null, not a party-line default.
-- =============================================================================
create table if not exists public.legislators (
  id                  uuid          primary key default gen_random_uuid(),

  -- Identity
  chamber             text          not null check (chamber in ('house', 'senate')),
  district            integer       not null check (district > 0),
  full_name           text          not null,
  party               text          not null check (party in ('D', 'R', 'I')),

  -- Composite unique key: a (chamber, district) tuple identifies exactly
  -- one seat at any given time. If a legislator leaves mid-session and
  -- is replaced, the replacement gets a new row (the departing row gets
  -- is_active = false).
  unique (chamber, district, is_active),

  -- Editorial scores (component values before aggregation)
  votes_score         integer       not null default 0,   -- was `v` in JS
  sponsorship_score   integer       not null default 0,   -- was `s` in JS
  news_score          integer       not null default 0,   -- was `n` in JS

  -- Narrative
  notes               text,

  -- Metadata
  seated_since        date,                                 -- null means "seated at start of session"
  portrait_url        text,                                 -- optional, for future use
  leadership_role     text,                                 -- e.g. "Minority Leader", "Speaker Pro Tem"
  is_active           boolean       not null default true,  -- soft-delete for retired or replaced members

  created_at          timestamptz   not null default now(),
  updated_at          timestamptz   not null default now()
);

comment on table public.legislators is
  'Ohio state legislators with editorial scoring data. Replaces HOUSE_MEMBERS and SENATE_MEMBERS arrays in /js/scorecard-data.js.';
comment on column public.legislators.votes_score is
  'Editorial judgment of voting record, typically -5 to +5. Combined with sponsorship and news scores to produce the weighted 0-100 total.';
comment on column public.legislators.seated_since is
  'Date the legislator took office. Null means seated at the start of the current General Assembly. Used by the vote resolver to avoid attributing votes to members not yet seated.';

create index if not exists legislators_chamber_district_idx
  on public.legislators (chamber, district);
create index if not exists legislators_party_idx
  on public.legislators (party) where is_active = true;

drop trigger if exists set_legislators_updated_at on public.legislators;
create trigger set_legislators_updated_at
  before update on public.legislators
  for each row execute function public.set_updated_at();


-- =============================================================================
-- TABLE: roll_calls
-- -----------------------------------------------------------------------------
-- One row per recorded floor vote on a bill we track. Not every tracked
-- bill has a roll call (most are still in committee), and some bills
-- have multiple roll calls (passage, concurrence, override). The
-- composite key (bill_slug, chamber, stage) uniquely identifies each.
--
-- `stance` records whether the bill is anti or pro-equality FROM THE
-- EQUALITY PERSPECTIVE. This is what the vote resolver uses to determine
-- party-line defaults: on anti bills, Republicans default to Yes and
-- Democrats to No; on pro bills, the defaults flip.
--
-- We reference bills by slug rather than by foreign key because some
-- roll calls in voting-records.js reference bills that predate our
-- tracker (HB 68, SB 104, HB 8 from the 135th GA). Storing slug as text
-- rather than uuid means we can record roll calls for bills we never
-- tracked individually without having to backfill the bills table.
-- =============================================================================
create table if not exists public.roll_calls (
  id                uuid          primary key default gen_random_uuid(),

  bill_slug         text          not null,                            -- links loosely to bills.slug
  bill_label        text          not null,                            -- "HB 249", for display when bill not in our tracker
  general_assembly  integer       not null default 136,                -- session number
  chamber           text          not null check (chamber in ('house', 'senate')),
  stage             text          not null,                            -- "pass", "concurrence", "override", etc.
  label             text          not null,                            -- "House Passage", "Senate Override", etc.
  vote_date         date          not null,
  result            text          not null,                            -- "Passed 63-32", "Failed 44-54"
  stance            text          not null check (stance in ('anti', 'pro')),
  notes             text,                                              -- context about the vote

  created_at        timestamptz   not null default now(),
  updated_at        timestamptz   not null default now(),

  unique (bill_slug, chamber, stage, general_assembly)
);

comment on table public.roll_calls is
  'Recorded floor votes on tracked bills. Party-line defaults plus exceptions from legislator_vote_exceptions resolve any legislator''s vote.';
comment on column public.roll_calls.stance is
  'Bill stance from the equality perspective. Drives the party-line defaults: anti-bill R=Y D=N, pro-bill R=N D=Y.';

create index if not exists roll_calls_bill_slug_idx on public.roll_calls (bill_slug);
create index if not exists roll_calls_date_idx      on public.roll_calls (vote_date desc);

drop trigger if exists set_roll_calls_updated_at on public.roll_calls;
create trigger set_roll_calls_updated_at
  before update on public.roll_calls
  for each row execute function public.set_updated_at();


-- =============================================================================
-- TABLE: legislator_vote_exceptions
-- -----------------------------------------------------------------------------
-- Documents any legislator whose vote on a roll call differs from their
-- party-line default. One row per documented exception. Everything else
-- resolves via the default logic.
--
-- `vote` uses the standard single-letter codes: Y (yea), N (nay),
-- A (abstained or absent), X (excused). These match the conventions in
-- voting-records.js.
-- =============================================================================
create table if not exists public.legislator_vote_exceptions (
  id              uuid          primary key default gen_random_uuid(),
  roll_call_id    uuid          not null references public.roll_calls(id) on delete cascade,
  legislator_id   uuid          not null references public.legislators(id) on delete cascade,
  vote            text          not null check (vote in ('Y', 'N', 'A', 'X')),
  notes           text,                                                  -- optional context
  created_at      timestamptz   not null default now(),

  unique (roll_call_id, legislator_id)
);

comment on table public.legislator_vote_exceptions is
  'Documented exceptions from party-line vote defaults. Absence of a row for (roll_call, legislator) means the legislator voted with their party line.';

create index if not exists legislator_vote_exceptions_legislator_idx
  on public.legislator_vote_exceptions (legislator_id);


-- =============================================================================
-- FUNCTION: calc_score(votes, sponsorship, news)
-- -----------------------------------------------------------------------------
-- Computes the weighted 0-to-100 score from the three component scores.
-- Mirrors the calcScore function in /js/scorecard-data.js exactly:
--   raw = v + s + n
--   score = clamp(50 + raw * 5, 0, 100)
--
-- Marked IMMUTABLE because the output depends only on the inputs. This
-- lets Postgres use it in indexes and generated columns if we ever need
-- to.
-- =============================================================================
create or replace function public.calc_score(
  votes_score integer,
  sponsorship_score integer,
  news_score integer
)
returns integer
language sql
immutable
as $$
  select greatest(0, least(100,
    round(50 + (coalesce(votes_score, 0) + coalesce(sponsorship_score, 0) + coalesce(news_score, 0)) * 5)
  ))::integer
$$;


-- =============================================================================
-- FUNCTION: calc_grade(score)
-- -----------------------------------------------------------------------------
-- Returns the grade row whose min_score is the highest value not
-- exceeding the given score. Mirrors calcGrade in the JS, but reads from
-- grade_scale instead of a hardcoded array.
--
-- Marked STABLE (not IMMUTABLE) because it reads from a table whose
-- values can change.
-- =============================================================================
create or replace function public.calc_grade(score integer)
returns table (grade text, label text, color_hex text)
language sql
stable
as $$
  select g.grade, g.label, g.color_hex
  from public.grade_scale g
  where g.is_active = true
    and g.min_score <= coalesce(score, 0)
  order by g.min_score desc
  limit 1
$$;


-- =============================================================================
-- VIEW: legislators_scored_public
-- -----------------------------------------------------------------------------
-- The view that the /scorecard page reads. Joins legislators with their
-- computed score, grade, and grade color. Filters to is_active = true so
-- retired members don't appear on the public page (though they remain
-- in the table for historical queries).
--
-- We compute score and grade in the view rather than storing them as
-- columns on the legislators table because they're cheap to derive and
-- keeping them out of the table means the scoring logic lives in one
-- place (the calc_score and calc_grade functions). If staff edits a
-- score component, the grade updates immediately without any trigger
-- bookkeeping.
-- =============================================================================
create or replace view public.legislators_scored_public as
select
  l.id,
  l.chamber,
  l.district,
  l.full_name,
  l.party,
  l.votes_score,
  l.sponsorship_score,
  l.news_score,
  l.notes,
  l.seated_since,
  l.leadership_role,
  l.updated_at,

  public.calc_score(l.votes_score, l.sponsorship_score, l.news_score) as score,

  -- Inline subquery to get the grade object. We use a subquery rather
  -- than a join because calc_grade returns at most one row and inlining
  -- keeps the view's row shape 1:1 with the legislators table.
  (
    select jsonb_build_object(
      'grade',     g.grade,
      'label',     g.label,
      'color_hex', g.color_hex
    )
    from public.calc_grade(
      public.calc_score(l.votes_score, l.sponsorship_score, l.news_score)
    ) g
  ) as grade

from public.legislators l
where l.is_active = true;

comment on view public.legislators_scored_public is
  'Active legislators with computed score and grade. Safe for public read access.';


-- =============================================================================
-- FUNCTION: resolve_legislator_vote(legislator_id, roll_call_id)
-- -----------------------------------------------------------------------------
-- Returns the vote ('Y', 'N', 'A', 'X', or null for not-yet-seated) for
-- a given legislator on a given roll call. Implements the three-step
-- resolution the JS `resolveVote` function uses:
--
--   1. If there's an exception row for (legislator, roll_call), use it.
--   2. If the legislator's seated_since is later than the vote_date,
--      return null.
--   3. Apply the party-line default given the bill's stance.
--
-- This function is what per-legislator or per-bill voting-history views
-- will build on when we add them later.
-- =============================================================================
create or replace function public.resolve_legislator_vote(
  p_legislator_id uuid,
  p_roll_call_id  uuid
)
returns text
language plpgsql
stable
as $$
declare
  v_exception   text;
  v_party       text;
  v_seated      date;
  v_vote_date   date;
  v_stance      text;
begin
  -- Step 1: exception row
  select vote into v_exception
  from public.legislator_vote_exceptions
  where legislator_id = p_legislator_id
    and roll_call_id = p_roll_call_id;

  if v_exception is not null then
    return v_exception;
  end if;

  -- Step 2: seated check
  select party, seated_since into v_party, v_seated
  from public.legislators
  where id = p_legislator_id;

  select vote_date, stance into v_vote_date, v_stance
  from public.roll_calls
  where id = p_roll_call_id;

  if v_seated is not null and v_seated > v_vote_date then
    return null;
  end if;

  -- Step 3: party-line default
  -- Anti-equality bill: R defaults to Y, D defaults to N
  -- Pro-equality bill:  R defaults to N, D defaults to Y
  if v_stance = 'anti' then
    if v_party = 'R' then return 'Y';
    elsif v_party = 'D' then return 'N';
    else return null;  -- Independents have no party-line default
    end if;
  elsif v_stance = 'pro' then
    if v_party = 'R' then return 'N';
    elsif v_party = 'D' then return 'Y';
    else return null;
    end if;
  end if;

  return null;
end;
$$;

comment on function public.resolve_legislator_vote(uuid, uuid) is
  'Three-step vote resolution: exception row, seating check, party-line default. Mirrors resolveVote in /js/voting-records.js.';


-- =============================================================================
-- RLS + GRANTS
-- =============================================================================
alter table public.grade_scale                     enable row level security;
alter table public.legislators                     enable row level security;
alter table public.roll_calls                      enable row level security;
alter table public.legislator_vote_exceptions      enable row level security;

-- Public read of active rows
drop policy if exists "grade_scale read active" on public.grade_scale;
create policy "grade_scale read active"
  on public.grade_scale for select to anon, authenticated
  using (is_active = true);

drop policy if exists "legislators read active" on public.legislators;
create policy "legislators read active"
  on public.legislators for select to anon, authenticated
  using (is_active = true);

drop policy if exists "roll_calls read all" on public.roll_calls;
create policy "roll_calls read all"
  on public.roll_calls for select to anon, authenticated
  using (true);

drop policy if exists "legislator_vote_exceptions read all" on public.legislator_vote_exceptions;
create policy "legislator_vote_exceptions read all"
  on public.legislator_vote_exceptions for select to anon, authenticated
  using (true);

-- Service-role writes only
drop policy if exists "grade_scale service_role writes" on public.grade_scale;
create policy "grade_scale service_role writes"
  on public.grade_scale for all to service_role using (true) with check (true);

drop policy if exists "legislators service_role writes" on public.legislators;
create policy "legislators service_role writes"
  on public.legislators for all to service_role using (true) with check (true);

drop policy if exists "roll_calls service_role writes" on public.roll_calls;
create policy "roll_calls service_role writes"
  on public.roll_calls for all to service_role using (true) with check (true);

drop policy if exists "legislator_vote_exceptions service_role writes" on public.legislator_vote_exceptions;
create policy "legislator_vote_exceptions service_role writes"
  on public.legislator_vote_exceptions for all to service_role using (true) with check (true);

-- View + function grants
grant select on public.legislators_scored_public to anon, authenticated;
grant execute on function public.calc_score(integer, integer, integer) to anon, authenticated;
grant execute on function public.calc_grade(integer) to anon, authenticated;
grant execute on function public.resolve_legislator_vote(uuid, uuid) to anon, authenticated;


-- =============================================================================
-- SEED: grade_scale
-- -----------------------------------------------------------------------------
-- Copied directly from the GRADE_SCALE constant in
-- /js/scorecard-data.js. Thresholds and colors preserved exactly.
-- =============================================================================
insert into public.grade_scale (grade, label, min_score, color_hex, display_order) values
  ('A+', 'Champion',      90, '#16a34a', 10),
  ('A',  'Strong Ally',   73, '#22c55e', 20),
  ('B',  'Supportive',    55, '#84cc16', 30),
  ('C',  'Mixed Record',  40, '#eab308', 40),
  ('D',  'Unfriendly',    20, '#f97316', 50),
  ('F',  'Hostile',        0, '#dc2626', 60)
on conflict (grade) do nothing;


-- =============================================================================
-- SEED HELPER: seed_legislator
-- -----------------------------------------------------------------------------
-- Convenience function for seeding many legislators at once. Makes the
-- generated seed file compact and readable.
-- =============================================================================
create or replace function public.seed_legislator(
  p_chamber          text,
  p_district         integer,
  p_full_name        text,
  p_party            text,
  p_votes_score      integer,
  p_sponsorship      integer,
  p_news_score       integer,
  p_notes            text,
  p_leadership_role  text default null,
  p_seated_since     date default null
)
returns uuid
language plpgsql
as $$
declare
  v_id uuid;
begin
  insert into public.legislators (
    chamber, district, full_name, party,
    votes_score, sponsorship_score, news_score,
    notes, leadership_role, seated_since
  ) values (
    p_chamber, p_district, p_full_name, p_party,
    p_votes_score, p_sponsorship, p_news_score,
    p_notes, p_leadership_role, p_seated_since
  )
  on conflict (chamber, district, is_active) do update set
    full_name         = excluded.full_name,
    party             = excluded.party,
    votes_score       = excluded.votes_score,
    sponsorship_score = excluded.sponsorship_score,
    news_score        = excluded.news_score,
    notes             = excluded.notes,
    leadership_role   = excluded.leadership_role,
    seated_since      = excluded.seated_since
  returning id into v_id;

  return v_id;
end;
$$;

comment on function public.seed_legislator(text, integer, text, text, integer, integer, integer, text, text, date) is
  'Upserts a legislator row by (chamber, district, is_active). Used by the generated seed file.';
