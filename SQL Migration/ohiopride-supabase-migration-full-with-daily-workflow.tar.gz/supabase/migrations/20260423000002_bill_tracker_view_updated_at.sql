-- =============================================================================
-- Ohio Pride PAC - Migration 3 (patch): expose bills.updated_at in the public view
-- -----------------------------------------------------------------------------
-- The /issues page shows a "Last Updated" timestamp that the old
-- bill-data.js expressed via a hardcoded LAST_UPDATED constant. After the
-- migration to Supabase, the equivalent is the maximum updated_at across
-- all active bill rows. Exposing updated_at through the bills_public view
-- lets the client compute MAX(updated_at) locally with no extra query.
--
-- The view is dropped and recreated because Postgres does not allow
-- altering a view's column list in place. The recreate is otherwise
-- identical to the version in migration 3 — one new column, no other
-- changes.
-- =============================================================================

-- Drop the view first (must drop because we are adding a new column
-- and CREATE OR REPLACE does not support column additions on views).
drop view if exists public.bills_public;

create view public.bills_public as
select
  b.id,
  b.slug,
  b.bill_number,
  b.general_assembly,
  b.chamber,
  b.title,
  b.official_title,
  b.nickname,
  b.description,
  b.stance,
  b.current_step_index,
  b.danger_step_index,
  b.pipeline_dates,
  b.sponsors,
  b.last_action,
  b.next_date,
  b.house_vote,
  b.senate_vote,
  b.legislature_url,
  b.text_url,
  b.internal_url,
  b.introduced_date,
  b.is_featured,
  b.display_order,
  b.updated_at,                      -- NEW: exposed for the "Last Updated" card

  -- Status object
  jsonb_build_object(
    'slug',        s.slug,
    'label',       s.label,
    'short_label', s.short_label,
    'color_hex',   s.color_hex,
    'is_dead',     s.is_dead,
    'is_law',      s.is_law
  ) as status,

  -- Current pipeline step object
  (
    select jsonb_build_object(
      'chamber',     ps.chamber,
      'step_index',  ps.step_index,
      'label',       ps.label,
      'is_terminal', ps.is_terminal
    )
    from public.bill_pipeline_steps ps
    where ps.chamber = b.chamber and ps.step_index = b.current_step_index
    limit 1
  ) as current_step,

  -- Categories array
  coalesce(
    (
      select jsonb_agg(
        jsonb_build_object(
          'slug',      c.slug,
          'label',     c.label,
          'color_hex', c.color_hex
        )
        order by c.display_order, c.label
      )
      from public.bill_category_assignments bca
      join public.bill_categories c on c.id = bca.category_id and c.is_active
      where bca.bill_id = b.id
    ),
    '[]'::jsonb
  ) as categories

from public.bills b
join public.bill_statuses s on s.id = b.status_id
where b.is_active = true;

comment on view public.bills_public is
  'Denormalized read-only projection of bills with status, current step, categories, and updated_at pre-joined.';

grant select on public.bills_public to anon, authenticated;
